/*
  # Seed data for Auto Care application

  1. Seed Data
    - Workshops data
    - Workshop services
    - Workshop specialties
    - Price estimates for different vehicle makes and service types
*/

-- Seed workshops
INSERT INTO workshops (id, name, rating, review_count, image, location, distance, hours, phone)
VALUES
  ('11111111-1111-1111-1111-111111111111', 'Al-Faisal Auto Center', 4.8, 125, 'https://images.unsplash.com/photo-1540066019607-e5f69323a8dc?q=80&w=1000&auto=format&fit=crop', 'King Fahd Road, Riyadh', '3.2 km', '8:00 AM - 8:00 PM', '+966 12 345 6789'),
  ('22222222-2222-2222-2222-222222222222', 'Riyadh Motors Workshop', 4.6, 98, 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=1000&auto=format&fit=crop', 'Al Olaya, Riyadh', '5.7 km', '7:30 AM - 9:00 PM', '+966 12 345 8888'),
  ('33333333-3333-3333-3333-333333333333', 'Al-Saud Premium Auto', 4.7, 112, 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?q=80&w=1000&auto=format&fit=crop', 'Northern Ring Road, Riyadh', '8.3 km', '9:00 AM - 7:00 PM', '+966 12 345 7777'),
  ('44444444-4444-4444-4444-444444444444', 'Quick Fix Auto Center', 4.5, 87, 'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?q=80&w=1000&auto=format&fit=crop', 'Eastern Ring Road, Riyadh', '4.1 km', '8:00 AM - 6:00 PM', '+966 12 345 6666'),
  ('55555555-5555-5555-5555-555555555555', 'Prestige Car Care', 4.9, 145, 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?q=80&w=1000&auto=format&fit=crop', 'Diplomatic Quarter, Riyadh', '9.5 km', '10:00 AM - 8:00 PM', '+966 12 345 9999'),
  ('66666666-6666-6666-6666-666666666666', 'Al-Riyadh Tire & Service', 4.3, 76, 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?q=80&w=1000&auto=format&fit=crop', 'Western Ring Road, Riyadh', '7.2 km', '7:00 AM - 10:00 PM', '+966 12 345 5555');

-- Seed workshop services
INSERT INTO workshop_services (workshop_id, service)
VALUES
  -- Al-Faisal Auto Center
  ('11111111-1111-1111-1111-111111111111', 'Oil Change'),
  ('11111111-1111-1111-1111-111111111111', 'Brake Service'),
  ('11111111-1111-1111-1111-111111111111', 'Engine Repair'),
  ('11111111-1111-1111-1111-111111111111', 'A/C Service'),
  ('11111111-1111-1111-1111-111111111111', 'Electrical Systems'),
  ('11111111-1111-1111-1111-111111111111', 'Transmission'),
  
  -- Riyadh Motors Workshop
  ('22222222-2222-2222-2222-222222222222', 'Full Service'),
  ('22222222-2222-2222-2222-222222222222', 'Body Work'),
  ('22222222-2222-2222-2222-222222222222', 'Painting'),
  ('22222222-2222-2222-2222-222222222222', 'Detailing'),
  ('22222222-2222-2222-2222-222222222222', 'Tire Service'),
  ('22222222-2222-2222-2222-222222222222', 'Diagnostic'),
  
  -- Al-Saud Premium Auto
  ('33333333-3333-3333-3333-333333333333', 'Performance Tuning'),
  ('33333333-3333-3333-3333-333333333333', 'Computer Diagnostics'),
  ('33333333-3333-3333-3333-333333333333', 'Suspension'),
  ('33333333-3333-3333-3333-333333333333', 'Transmission'),
  ('33333333-3333-3333-3333-333333333333', 'Body Work'),
  ('33333333-3333-3333-3333-333333333333', 'Interior Repair'),
  
  -- Quick Fix Auto Center
  ('44444444-4444-4444-4444-444444444444', 'Oil Change'),
  ('44444444-4444-4444-4444-444444444444', 'Filter Replacement'),
  ('44444444-4444-4444-4444-444444444444', 'Battery Service'),
  ('44444444-4444-4444-4444-444444444444', 'Tire Change'),
  ('44444444-4444-4444-4444-444444444444', 'A/C Recharge'),
  ('44444444-4444-4444-4444-444444444444', 'Basic Maintenance'),
  
  -- Prestige Car Care
  ('55555555-5555-5555-5555-555555555555', 'Premium Service'),
  ('55555555-5555-5555-5555-555555555555', 'Interior Detailing'),
  ('55555555-5555-5555-5555-555555555555', 'Ceramic Coating'),
  ('55555555-5555-5555-5555-555555555555', 'Custom Wheels'),
  ('55555555-5555-5555-5555-555555555555', 'Performance Upgrades'),
  ('55555555-5555-5555-5555-555555555555', 'Premium Diagnostics'),
  
  -- Al-Riyadh Tire & Service
  ('66666666-6666-6666-6666-666666666666', 'Tire Sales'),
  ('66666666-6666-6666-6666-666666666666', 'Tire Repair'),
  ('66666666-6666-6666-6666-666666666666', 'Wheel Alignment'),
  ('66666666-6666-6666-6666-666666666666', 'Balancing'),
  ('66666666-6666-6666-6666-666666666666', 'Suspension'),
  ('66666666-6666-6666-6666-666666666666', 'Brake Service');

-- Seed workshop specialties
INSERT INTO workshop_specialties (workshop_id, specialty)
VALUES
  -- Al-Faisal Auto Center
  ('11111111-1111-1111-1111-111111111111', 'Toyota'),
  ('11111111-1111-1111-1111-111111111111', 'Lexus'),
  ('11111111-1111-1111-1111-111111111111', 'Honda'),
  ('11111111-1111-1111-1111-111111111111', 'Premium Cars'),
  
  -- Riyadh Motors Workshop
  ('22222222-2222-2222-2222-222222222222', 'General Repairs'),
  ('22222222-2222-2222-2222-222222222222', 'European Cars'),
  ('22222222-2222-2222-2222-222222222222', 'Accident Repairs'),
  
  -- Al-Saud Premium Auto
  ('33333333-3333-3333-3333-333333333333', 'Luxury Vehicles'),
  ('33333333-3333-3333-3333-333333333333', 'Custom Modifications'),
  ('33333333-3333-3333-3333-333333333333', 'German Cars'),
  
  -- Quick Fix Auto Center
  ('44444444-4444-4444-4444-444444444444', 'Fast Service'),
  ('44444444-4444-4444-4444-444444444444', 'Japanese Cars'),
  ('44444444-4444-4444-4444-444444444444', 'Routine Maintenance'),
  
  -- Prestige Car Care
  ('55555555-5555-5555-5555-555555555555', 'Luxury Brands'),
  ('55555555-5555-5555-5555-555555555555', 'Sports Cars'),
  ('55555555-5555-5555-5555-555555555555', 'Premium Detailing'),
  
  -- Al-Riyadh Tire & Service
  ('66666666-6666-6666-6666-666666666666', 'Tire Specialist'),
  ('66666666-6666-6666-6666-666666666666', 'Wheel Services'),
  ('66666666-6666-6666-6666-666666666666', 'Suspension Work');

-- Seed price estimates
INSERT INTO price_estimates (vehicle_make, service_type, min_price, max_price)
VALUES
  -- Toyota
  ('toyota', 'regular', 200, 350),
  ('toyota', 'repair', 400, 800),
  ('toyota', 'accident', 1200, 3000),
  ('toyota', 'diagnostic', 150, 250),
  ('toyota', 'parts', 300, 700),
  
  -- Honda
  ('honda', 'regular', 220, 380),
  ('honda', 'repair', 450, 850),
  ('honda', 'accident', 1300, 3200),
  ('honda', 'diagnostic', 160, 270),
  ('honda', 'parts', 320, 750),
  
  -- Nissan
  ('nissan', 'regular', 190, 340),
  ('nissan', 'repair', 380, 780),
  ('nissan', 'accident', 1150, 2900),
  ('nissan', 'diagnostic', 140, 240),
  ('nissan', 'parts', 290, 680),
  
  -- Ford
  ('ford', 'regular', 250, 420),
  ('ford', 'repair', 500, 950),
  ('ford', 'accident', 1400, 3500),
  ('ford', 'diagnostic', 180, 300),
  ('ford', 'parts', 350, 800),
  
  -- Chevrolet
  ('chevrolet', 'regular', 230, 400),
  ('chevrolet', 'repair', 480, 900),
  ('chevrolet', 'accident', 1350, 3300),
  ('chevrolet', 'diagnostic', 170, 280),
  ('chevrolet', 'parts', 330, 770),
  
  -- BMW
  ('bmw', 'regular', 350, 600),
  ('bmw', 'repair', 700, 1500),
  ('bmw', 'accident', 2000, 5000),
  ('bmw', 'diagnostic', 250, 450),
  ('bmw', 'parts', 600, 1200),
  
  -- Mercedes
  ('mercedes', 'regular', 380, 650),
  ('mercedes', 'repair', 750, 1600),
  ('mercedes', 'accident', 2200, 5500),
  ('mercedes', 'diagnostic', 280, 480),
  ('mercedes', 'parts', 650, 1300),
  
  -- Audi
  ('audi', 'regular', 360, 620),
  ('audi', 'repair', 720, 1550),
  ('audi', 'accident', 2100, 5200),
  ('audi', 'diagnostic', 260, 460),
  ('audi', 'parts', 620, 1250),
  
  -- Kia
  ('kia', 'regular', 180, 320),
  ('kia', 'repair', 350, 750),
  ('kia', 'accident', 1100, 2800),
  ('kia', 'diagnostic', 130, 230),
  ('kia', 'parts', 280, 650),
  
  -- Hyundai
  ('hyundai', 'regular', 170, 310),
  ('hyundai', 'repair', 340, 730),
  ('hyundai', 'accident', 1050, 2700),
  ('hyundai', 'diagnostic', 125, 220),
  ('hyundai', 'parts', 270, 630);