/*
  # Add workshop owner authentication and management

  1. New Tables
    - `workshop_owners` - Stores workshop owner information and business details
  
  2. Security
    - Enable RLS on workshop_owners table
    - Add policies for authenticated users
*/

-- Create workshop_owners table
CREATE TABLE IF NOT EXISTS workshop_owners (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  business_name TEXT NOT NULL,
  business_license TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  contact_phone TEXT NOT NULL,
  contact_email TEXT NOT NULL,
  verified BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE workshop_owners ENABLE ROW LEVEL SECURITY;

-- Create policies for workshop_owners
CREATE POLICY "Users can read their own workshop owner profile"
  ON workshop_owners
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own workshop owner profile"
  ON workshop_owners
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own workshop owner profile"
  ON workshop_owners
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Add trigger to handle updated_at
CREATE TRIGGER update_workshop_owners_updated_at
  BEFORE UPDATE ON workshop_owners
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();