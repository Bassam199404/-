/*
  # Initial schema setup for Auto Care application

  1. New Tables
    - `vehicles` - Stores vehicle information submitted by users
    - `workshops` - Stores workshop information
    - `workshop_services` - Stores services offered by workshops
    - `workshop_specialties` - Stores specialties of workshops
    - `vehicle_images` - Stores images uploaded for vehicles
    - `price_estimates` - Stores price estimates for different vehicle makes and service types
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read and manage their own data
*/

-- Create vehicles table
CREATE TABLE IF NOT EXISTS vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ DEFAULT now(),
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  year INTEGER NOT NULL,
  mileage INTEGER NOT NULL,
  service_type TEXT NOT NULL,
  description TEXT NOT NULL,
  user_id UUID REFERENCES auth.users(id)
);

-- Create workshops table
CREATE TABLE IF NOT EXISTS workshops (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ DEFAULT now(),
  name TEXT NOT NULL,
  rating NUMERIC(3,1) NOT NULL,
  review_count INTEGER NOT NULL,
  image TEXT NOT NULL,
  location TEXT NOT NULL,
  distance TEXT NOT NULL,
  hours TEXT NOT NULL,
  phone TEXT NOT NULL
);

-- Create workshop_services table
CREATE TABLE IF NOT EXISTS workshop_services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workshop_id UUID REFERENCES workshops(id) ON DELETE CASCADE,
  service TEXT NOT NULL
);

-- Create workshop_specialties table
CREATE TABLE IF NOT EXISTS workshop_specialties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workshop_id UUID REFERENCES workshops(id) ON DELETE CASCADE,
  specialty TEXT NOT NULL
);

-- Create vehicle_images table
CREATE TABLE IF NOT EXISTS vehicle_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID REFERENCES vehicles(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create price_estimates table
CREATE TABLE IF NOT EXISTS price_estimates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_make TEXT NOT NULL,
  service_type TEXT NOT NULL,
  min_price INTEGER NOT NULL,
  max_price INTEGER NOT NULL,
  UNIQUE(vehicle_make, service_type)
);

-- Enable Row Level Security
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE workshops ENABLE ROW LEVEL SECURITY;
ALTER TABLE workshop_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE workshop_specialties ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicle_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE price_estimates ENABLE ROW LEVEL SECURITY;

-- Create policies for vehicles
CREATE POLICY "Users can read their own vehicles"
  ON vehicles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own vehicles"
  ON vehicles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own vehicles"
  ON vehicles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own vehicles"
  ON vehicles
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for vehicle_images
CREATE POLICY "Users can read their own vehicle images"
  ON vehicle_images
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM vehicles
    WHERE vehicles.id = vehicle_images.vehicle_id
    AND vehicles.user_id = auth.uid()
  ));

CREATE POLICY "Users can insert their own vehicle images"
  ON vehicle_images
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM vehicles
    WHERE vehicles.id = vehicle_images.vehicle_id
    AND vehicles.user_id = auth.uid()
  ));

CREATE POLICY "Users can delete their own vehicle images"
  ON vehicle_images
  FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM vehicles
    WHERE vehicles.id = vehicle_images.vehicle_id
    AND vehicles.user_id = auth.uid()
  ));

-- Create policies for workshops (public read)
CREATE POLICY "Anyone can read workshops"
  ON workshops
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Create policies for workshop_services (public read)
CREATE POLICY "Anyone can read workshop services"
  ON workshop_services
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Create policies for workshop_specialties (public read)
CREATE POLICY "Anyone can read workshop specialties"
  ON workshop_specialties
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Create policies for price_estimates (public read)
CREATE POLICY "Anyone can read price estimates"
  ON price_estimates
  FOR SELECT
  TO anon, authenticated
  USING (true);