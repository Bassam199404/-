import { supabase, fallbackWorkshops } from '../lib/supabase';
import { toast } from 'sonner';
import { createTables } from './createTables';

// Workshop data
const workshopsData = [
  {
    id: "11111111-1111-1111-1111-111111111111",
    name: "Al-Faisal Auto Center",
    rating: 4.8,
    review_count: 125,
    image: "https://images.unsplash.com/photo-1540066019607-e5f69323a8dc?q=80&w=1000&auto=format&fit=crop",
    location: "King Fahd Road, Riyadh",
    distance: "3.2 km",
    hours: "8:00 AM - 8:00 PM",
    phone: "+966 12 345 6789"
  },
  {
    id: "22222222-2222-2222-2222-222222222222",
    name: "Riyadh Motors Workshop",
    rating: 4.6,
    review_count: 98,
    image: "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=1000&auto=format&fit=crop",
    location: "Al Olaya, Riyadh",
    distance: "5.7 km",
    hours: "7:30 AM - 9:00 PM",
    phone: "+966 12 345 8888"
  },
  {
    id: "33333333-3333-3333-3333-333333333333",
    name: "Al-Saud Premium Auto",
    rating: 4.7,
    review_count: 112,
    image: "https://images.unsplash.com/photo-1583121274602-3e2820c69888?q=80&w=1000&auto=format&fit=crop",
    location: "Northern Ring Road, Riyadh",
    distance: "8.3 km",
    hours: "9:00 AM - 7:00 PM",
    phone: "+966 12 345 7777"
  },
  {
    id: "44444444-4444-4444-4444-444444444444",
    name: "Quick Fix Auto Center",
    rating: 4.5,
    review_count: 87,
    image: "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?q=80&w=1000&auto=format&fit=crop",
    location: "Eastern Ring Road, Riyadh",
    distance: "4.1 km",
    hours: "8:00 AM - 6:00 PM",
    phone: "+966 12 345 6666"
  },
  {
    id: "55555555-5555-5555-5555-555555555555",
    name: "Prestige Car Care",
    rating: 4.9,
    review_count: 145,
    image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?q=80&w=1000&auto=format&fit=crop",
    location: "Diplomatic Quarter, Riyadh",
    distance: "9.5 km",
    hours: "10:00 AM - 8:00 PM",
    phone: "+966 12 345 9999"
  },
  {
    id: "66666666-6666-6666-6666-666666666666",
    name: "Al-Riyadh Tire & Service",
    rating: 4.3,
    review_count: 76,
    image: "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?q=80&w=1000&auto=format&fit=crop",
    location: "Western Ring Road, Riyadh",
    distance: "7.2 km",
    hours: "7:00 AM - 10:00 PM",
    phone: "+966 12 345 5555"
  }
];

// Workshop services data
const workshopServicesData = [
  // Al-Faisal Auto Center
  { workshop_id: "11111111-1111-1111-1111-111111111111", service: "Oil Change" },
  { workshop_id: "11111111-1111-1111-1111-111111111111", service: "Brake Service" },
  { workshop_id: "11111111-1111-1111-1111-111111111111", service: "Engine Repair" },
  { workshop_id: "11111111-1111-1111-1111-111111111111", service: "A/C Service" },
  { workshop_id: "11111111-1111-1111-1111-111111111111", service: "Electrical Systems" },
  { workshop_id: "11111111-1111-1111-1111-111111111111", service: "Transmission" },
  
  // Riyadh Motors Workshop
  { workshop_id: "22222222-2222-2222-2222-222222222222", service: "Full Service" },
  { workshop_id: "22222222-2222-2222-2222-222222222222", service: "Body Work" },
  { workshop_id: "22222222-2222-2222-2222-222222222222", service: "Painting" },
  { workshop_id: "22222222-2222-2222-2222-222222222222", service: "Detailing" },
  { workshop_id: "22222222-2222-2222-2222-222222222222", service: "Tire Service" },
  { workshop_id: "22222222-2222-2222-2222-222222222222", service: "Diagnostic" }
];

// Workshop specialties data
const workshopSpecialtiesData = [
  // Al-Faisal Auto Center
  { workshop_id: "11111111-1111-1111-1111-111111111111", specialty: "Toyota" },
  { workshop_id: "11111111-1111-1111-1111-111111111111", specialty: "Lexus" },
  { workshop_id: "11111111-1111-1111-1111-111111111111", specialty: "Honda" },
  { workshop_id: "11111111-1111-1111-1111-111111111111", specialty: "Premium Cars" },
  
  // Riyadh Motors Workshop
  { workshop_id: "22222222-2222-2222-2222-222222222222", specialty: "General Repairs" },
  { workshop_id: "22222222-2222-2222-2222-222222222222", specialty: "European Cars" },
  { workshop_id: "22222222-2222-2222-2222-222222222222", specialty: "Accident Repairs" }
];

// Price estimates data
const priceEstimatesData = [
  // Toyota
  { vehicle_make: 'toyota', service_type: 'regular', min_price: 200, max_price: 350 },
  { vehicle_make: 'toyota', service_type: 'repair', min_price: 400, max_price: 800 },
  { vehicle_make: 'toyota', service_type: 'accident', min_price: 1200, max_price: 3000 }
];

// Function to check if workshops already exist
export const checkExistingWorkshops = async () => {
  try {
    const { data, error } = await supabase
      .from('workshops')
      .select('id')
      .limit(1);
    
    if (error) {
      console.log("Error checking existing workshops:", error);
      return false;
    }
    
    return data && data.length > 0;
  } catch (error) {
    console.log("Error checking existing workshops:", error);
    return false;
  }
};

// Function to insert workshops
export const insertWorkshops = async () => {
  try {
    // Try to insert just one workshop to test if we have permission
    const { error: testError } = await supabase
      .from('workshops')
      .insert(workshopsData[0]);
    
    if (testError) {
      console.log("Cannot insert workshops, likely due to permissions:", testError);
      return false;
    }
    
    // If the test was successful, insert the rest
    for (let i = 1; i < workshopsData.length; i++) {
      const { error } = await supabase
        .from('workshops')
        .insert(workshopsData[i]);
      
      if (error && error.code !== '23505') { // Ignore duplicate key errors
        console.log("Error inserting workshop:", workshopsData[i].name, error);
        // Continue with the next workshop instead of failing completely
      }
    }
    
    console.log("Workshops inserted successfully");
    return true;
  } catch (error) {
    console.log("Error inserting workshops:", error);
    return false;
  }
};

// Function to insert workshop services
export const insertWorkshopServices = async () => {
  try {
    // Try to insert just one service to test if we have permission
    const { error: testError } = await supabase
      .from('workshop_services')
      .insert(workshopServicesData[0]);
    
    if (testError) {
      console.log("Cannot insert workshop services, likely due to permissions:", testError);
      return false;
    }
    
    // If the test was successful, insert the rest in batches
    const batchSize = 3;
    for (let i = 1; i < workshopServicesData.length; i += batchSize) {
      const batch = workshopServicesData.slice(i, i + batchSize);
      const { error } = await supabase
        .from('workshop_services')
        .insert(batch);
      
      if (error && error.code !== '23505') { // Ignore duplicate key errors
        console.log("Error inserting workshop services batch:", error);
        // Continue with the next batch instead of failing completely
      }
    }
    
    console.log("Workshop services inserted successfully");
    return true;
  } catch (error) {
    console.log("Error inserting workshop services:", error);
    return false;
  }
};

// Function to insert workshop specialties
export const insertWorkshopSpecialties = async () => {
  try {
    // Try to insert just one specialty to test if we have permission
    const { error: testError } = await supabase
      .from('workshop_specialties')
      .insert(workshopSpecialtiesData[0]);
    
    if (testError) {
      console.log("Cannot insert workshop specialties, likely due to permissions:", testError);
      return false;
    }
    
    // If the test was successful, insert the rest in batches
    const batchSize = 3;
    for (let i = 1; i < workshopSpecialtiesData.length; i += batchSize) {
      const batch = workshopSpecialtiesData.slice(i, i + batchSize);
      const { error } = await supabase
        .from('workshop_specialties')
        .insert(batch);
      
      if (error && error.code !== '23505') { // Ignore duplicate key errors
        console.log("Error inserting workshop specialties batch:", error);
        // Continue with the next batch instead of failing completely
      }
    }
    
    console.log("Workshop specialties inserted successfully");
    return true;
  } catch (error) {
    console.log("Error inserting workshop specialties:", error);
    return false;
  }
};

// Function to insert price estimates
export const insertPriceEstimates = async () => {
  try {
    // Try to insert just one price estimate to test if we have permission
    const { error: testError } = await supabase
      .from('price_estimates')
      .insert(priceEstimatesData[0]);
    
    if (testError) {
      console.log("Cannot insert price estimates, likely due to permissions:", testError);
      return false;
    }
    
    // If the test was successful, insert the rest in batches
    const batchSize = 3;
    for (let i = 1; i < priceEstimatesData.length; i += batchSize) {
      const batch = priceEstimatesData.slice(i, i + batchSize);
      const { error } = await supabase
        .from('price_estimates')
        .insert(batch);
      
      if (error && error.code !== '23505') { // Ignore duplicate key errors
        console.log("Error inserting price estimates batch:", error);
        // Continue with the next batch instead of failing completely
      }
    }
    
    console.log("Price estimates inserted successfully");
    return true;
  } catch (error) {
    console.log("Error inserting price estimates:", error);
    return false;
  }
};

// Main function to migrate all data
export const migrateAllData = async () => {
  try {
    // First, check if we can connect to Supabase
    try {
      const { error: connectionError } = await supabase.auth.getSession();
      
      if (connectionError) {
        console.log("Connection to Supabase failed:", connectionError);
        return { success: false, message: "Could not connect to Supabase. Using fallback data." };
      }
    } catch (error) {
      console.log("Error checking Supabase connection:", error);
      return { success: false, message: "Could not connect to Supabase. Using fallback data." };
    }

    // Check if tables exist
    const tablesResult = await createTables();
    if (!tablesResult.success) {
      console.log("Table checks failed:", tablesResult.message);
      return { success: false, message: "Using fallback data for demonstration." };
    }
    
    // Check if workshops already exist
    const workshopsExist = await checkExistingWorkshops();
    if (workshopsExist) {
      console.log("Workshops already exist in the database");
      return { success: true, message: "Using existing data from database." };
    }
    
    // Try to insert data, but don't worry if it fails
    // We'll just use fallback data in that case
    let dataInserted = false;
    
    // Insert workshops
    const workshopsInserted = await insertWorkshops();
    if (workshopsInserted) {
      dataInserted = true;
      
      // Only try to insert related data if workshops were inserted successfully
      await insertWorkshopServices();
      await insertWorkshopSpecialties();
      await insertPriceEstimates();
    }
    
    if (dataInserted) {
      return { success: true, message: "Data inserted successfully." };
    } else {
      return { success: false, message: "Could not insert data. Using fallback data." };
    }
  } catch (error) {
    console.log("Error in data migration:", error);
    return { success: false, message: "An error occurred during data migration. Using fallback data." };
  }
};