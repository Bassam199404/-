import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';

interface LanguageContextType {
  isArabic: boolean;
  setIsArabic: (value: boolean) => void;
  toggleLanguage: () => void;
  dir: 'ltr' | 'rtl';
  fontFamily: string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Try to get language preference from localStorage
  const [isArabic, setIsArabic] = useState(() => {
    const saved = localStorage.getItem('isArabic');
    return saved ? JSON.parse(saved) : false;
  });

  // Update localStorage when language changes
  useEffect(() => {
    localStorage.setItem('isArabic', JSON.stringify(isArabic));
    // Update document direction
    document.documentElement.dir = isArabic ? 'rtl' : 'ltr';
    // Add or remove a class to the html element for global styling
    if (isArabic) {
      document.documentElement.classList.add('arabic');
    } else {
      document.documentElement.classList.remove('arabic');
    }
  }, [isArabic]);

  const toggleLanguage = () => {
    setIsArabic(prev => !prev);
  };

  return (
    <LanguageContext.Provider value={{ 
      isArabic, 
      setIsArabic, 
      toggleLanguage,
      dir: isArabic ? 'rtl' : 'ltr',
      fontFamily: isArabic ? 'Noto Sans Arabic' : 'inherit'
    }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};