import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Car, Mail, ArrowLeft, ArrowRight } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import { resetPassword } from "../services/authService";

const ForgotPassword = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const result = await resetPassword(email);
      
      if (result.success) {
        setIsSubmitted(true);
        toast.success(isArabic 
          ? "تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني" 
          : "Password reset link sent to your email"
        );
      } else {
        toast.error(result.message || (isArabic ? "فشل إرسال رابط إعادة التعيين" : "Failed to send reset link"));
      }
    } catch (error) {
      console.log("Reset password error:", error);
      toast.error(isArabic ? "حدث خطأ أثناء إرسال رابط إعادة التعيين" : "An error occurred while sending reset link");
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div 
      className="min-h-screen flex flex-col"
      dir={dir}
      style={{ fontFamily }}
    >
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=2070&auto=format&fit=crop" 
          alt="Car workshop background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-black/70 mix-blend-multiply"></div>
      </div>
      
      {/* Content */}
      <div className="flex-grow flex items-center justify-center px-6 py-12 relative z-10">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="text-center mb-8">
            <Link to="/" className="inline-flex items-center justify-center">
              <Car className="h-10 w-10 text-white" />
              <span className="text-white text-2xl font-bold ml-2">
                {isArabic ? "صيانة سمارت" : "Maintenance Smart"}
              </span>
            </Link>
          </div>
          
          {/* Forgot Password Card */}
          <div className="glass-card rounded-xl p-8 backdrop-blur-md bg-white/90 shadow-xl">
            {!isSubmitted ? (
              <>
                <h1 className="text-2xl font-bold mb-2 text-center">
                  {isArabic ? "نسيت كلمة المرور؟" : "Forgot Password?"}
                </h1>
                <p className="text-gray-600 text-center mb-6">
                  {isArabic 
                    ? "أدخل بريدك الإلكتروني وسنرسل لك رابطًا لإعادة تعيين كلمة المرور" 
                    : "Enter your email and we'll send you a link to reset your password"
                  }
                </p>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Email Field */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {isArabic ? "البريد الإلكتروني" : "Email"}
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder={isArabic ? "أدخل بريدك الإلكتروني" : "Enter your email"}
                      />
                    </div>
                  </div>
                  
                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isLoading}
                    className={cn(
                      "w-full py-3 px-4 rounded-lg font-medium text-white transition-colors flex items-center justify-center",
                      isLoading 
                        ? "bg-primary/70 cursor-wait" 
                        : "bg-primary hover:bg-primary/90"
                    )}
                  >
                    {isLoading ? (
                      <>
                        <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        {isArabic ? "جاري الإرسال..." : "Sending..."}
                      </>
                    ) : (
                      <>
                        {isArabic ? "إرسال رابط إعادة التعيين" : "Send Reset Link"}
                        <ArrowRight className={cn("h-5 w-5", isArabic ? "mr-2 rotate-180" : "ml-2")} />
                      </>
                    )}
                  </button>
                </form>
              </>
            ) : (
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 text-green-500 rounded-full mb-4">
                  <Mail className="h-8 w-8" />
                </div>
                <h2 className="text-2xl font-bold mb-2">
                  {isArabic ? "تحقق من بريدك الإلكتروني" : "Check Your Email"}
                </h2>
                <p className="text-gray-600 mb-6">
                  {isArabic 
                    ? `لقد أرسلنا رابط إعادة تعيين كلمة المرور إلى ${email}` 
                    : `We've sent a password reset link to ${email}`
                  }
                </p>
                <p className="text-sm text-gray-500 mb-6">
                  {isArabic 
                    ? "إذا لم تجد الرسالة في صندوق الوارد، يرجى التحقق من مجلد البريد غير المرغوب فيه" 
                    : "If you don't see the email in your inbox, please check your spam folder"
                  }
                </p>
              </div>
            )}
            
            {/* Back to Login Link */}
            <div className="mt-6 text-center">
              <Link 
                to="/login" 
                className="inline-flex items-center text-primary font-medium hover:text-primary/80 transition-colors"
              >
                <ArrowLeft className={cn("h-4 w-4", isArabic ? "ml-2 rotate-180" : "mr-2")} />
                {isArabic ? "العودة إلى تسجيل الدخول" : "Back to Login"}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;