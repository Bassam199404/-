import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Star, MapPin, Clock, Phone, Wrench, ChevronLeft, Edit } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { cn } from '../lib/utils';
import { getWorkshopOwnerData } from '../services/workshopOwnerService';
import { toast } from 'sonner';

const WorkshopProfile = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  
  const [workshopData, setWorkshopData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const loadData = async () => {
      try {
        const result = await getWorkshopOwnerData();
        if (result.success && result.data) {
          setWorkshopData(result.data);
        } else {
          throw new Error('Failed to load workshop data');
        }
      } catch (error) {
        console.error('Error loading workshop data:', error);
        toast.error(isArabic ? 'فشل تحميل بيانات الورشة' : 'Failed to load workshop data');
        navigate('/workshop-owner');
      } finally {
        setLoading(false);
      }
    };
    
    if (isAuthenticated && user) {
      loadData();
    } else {
      navigate('/login', { state: { from: '/workshop-profile' } });
    }
  }, [isAuthenticated, user, navigate, isArabic]);
  
  if (!isAuthenticated || !user) {
    return null;
  }
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!workshopData?.workshops) {
    return (
      <div className="min-h-screen py-24 px-6">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-2xl font-bold mb-4">
            {isArabic ? 'لم يتم إضافة بيانات الورشة بعد' : 'Workshop data not added yet'}
          </h1>
          <p className="text-gray-600 mb-6">
            {isArabic 
              ? 'يرجى إضافة بيانات ورشتك للبدء'
              : 'Please add your workshop data to get started'
            }
          </p>
          <button
            onClick={() => navigate('/workshop-owner')}
            className="inline-flex items-center px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
          >
            {isArabic ? 'إضافة بيانات الورشة' : 'Add Workshop Data'}
          </button>
        </div>
      </div>
    );
  }
  
  const workshop = workshopData.workshops;
  const defaultImage = 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=1000&auto=format&fit=crop';
  const coverImage = workshop.image || workshop.images?.[0] || defaultImage;
  
  return (
    <div 
      className="min-h-screen py-24 px-6"
      dir={dir}
      style={{ fontFamily }}
    >
      <div className="container mx-auto max-w-4xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => navigate(-1)}
            className="inline-flex items-center text-gray-600 hover:text-gray-900"
          >
            <ChevronLeft className="h-5 w-5 mr-1" />
            {isArabic ? 'رجوع' : 'Back'}
          </button>
          
          <button
            onClick={() => navigate('/workshop-owner')}
            className="inline-flex items-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Edit className="h-4 w-4 mr-2" />
            {isArabic ? 'تعديل البيانات' : 'Edit Data'}
          </button>
        </div>
        
        {/* Workshop Info */}
        <div className="glass-card rounded-xl overflow-hidden">
          {/* Cover Image */}
          <div className="relative h-48 sm:h-64 bg-gray-100">
            <div className="absolute inset-0">
              <img
                src={coverImage}
                alt={workshop.name}
                className="w-full h-full object-cover"
              />
              <div 
                className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent"
                style={{ pointerEvents: 'none' }}
              ></div>
            </div>
            <div className="absolute bottom-4 left-4 right-4 z-10">
              <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
                {workshop.name}
              </h1>
              <div className="flex items-center text-white/90">
                <Star className="h-5 w-5 text-yellow-400 fill-yellow-400 mr-1" />
                <span className="font-medium">New</span>
                <span className="mx-2">•</span>
                <span>{workshop.review_count} {isArabic ? 'تقييم' : 'reviews'}</span>
              </div>
            </div>
          </div>
          
          {/* Content */}
          <div className="p-6 sm:p-8">
            {/* Basic Info */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
              <div className="flex items-start">
                <MapPin className="h-5 w-5 text-gray-400 mt-1 mr-3 flex-shrink-0" />
                <div>
                  <h3 className="font-medium mb-1">
                    {isArabic ? 'الموقع' : 'Location'}
                  </h3>
                  <p className="text-gray-600">{workshop.location}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Clock className="h-5 w-5 text-gray-400 mt-1 mr-3 flex-shrink-0" />
                <div>
                  <h3 className="font-medium mb-1">
                    {isArabic ? 'ساعات العمل' : 'Working Hours'}
                  </h3>
                  <p className="text-gray-600">{workshop.hours}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Phone className="h-5 w-5 text-gray-400 mt-1 mr-3 flex-shrink-0" />
                <div>
                  <h3 className="font-medium mb-1">
                    {isArabic ? 'رقم الهاتف' : 'Phone'}
                  </h3>
                  <p className="text-gray-600">{workshop.phone}</p>
                </div>
              </div>
            </div>
            
            {/* Description */}
            <div className="mb-8">
              <h2 className="text-lg font-semibold mb-3">
                {isArabic ? 'عن الورشة' : 'About'}
              </h2>
              <p className="text-gray-600">{workshop.description}</p>
            </div>
            
            {/* Services */}
            <div className="mb-8">
              <div className="flex items-center mb-3">
                <Wrench className="h-5 w-5 text-primary mr-2" />
                <h2 className="text-lg font-semibold">
                  {isArabic ? 'الخدمات' : 'Services'}
                </h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {workshop.services?.map((service: string, index: number) => (
                  <span 
                    key={index}
                    className="px-3 py-1 bg-gray-100 rounded-full text-sm"
                  >
                    {service}
                  </span>
                ))}
              </div>
            </div>
            
            {/* Specialties */}
            <div className="mb-8">
              <div className="flex items-center mb-3">
                <Wrench className="h-5 w-5 text-primary mr-2" />
                <h2 className="text-lg font-semibold">
                  {isArabic ? 'التخصصات' : 'Specialties'}
                </h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {workshop.specialties?.map((specialty: string, index: number) => (
                  <span 
                    key={index}
                    className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm"
                  >
                    {specialty}
                  </span>
                ))}
              </div>
            </div>
            
            {/* Gallery */}
            {(workshop.images?.length > 0 || workshop.image) && (
              <div>
                <h2 className="text-lg font-semibold mb-3">
                  {isArabic ? 'معرض الصور' : 'Gallery'}
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {/* Show main image first if it exists */}
                  {workshop.image && (
                    <div className="aspect-square rounded-lg overflow-hidden">
                      <img
                        src={workshop.image}
                        alt={`${workshop.name} main`}
                        className="w-full h-full object-cover hover:scale-105 transition-transform"
                      />
                    </div>
                  )}
                  
                  {/* Show additional images */}
                  {workshop.images?.map((image: string, index: number) => (
                    image !== workshop.image && (
                      <div key={index} className="aspect-square rounded-lg overflow-hidden">
                        <img
                          src={image}
                          alt={`${workshop.name} ${index + 1}`}
                          className="w-full h-full object-cover hover:scale-105 transition-transform"
                        />
                      </div>
                    )
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkshopProfile;