import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { ChevronLeft, Bot, User, Loader, Car, Wrench, Sparkles, MapPin, X } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import { getAiResponse } from "../services/aiService";
import { getCurrentLocation } from "../services/mapsService";
import { generateDeepSeekResponse, analyzeCarProblem, analyzeCarProblemFromImage } from "../services/deepseekService";
import ChatInput from "../components/ChatInput";

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  location?: {
    lat: number;
    lng: number;
    address?: string;
  };
  imageUrl?: string;
}

const AiAssistant = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Get user location
  useEffect(() => {
    const fetchLocation = async () => {
      try {
        const location = await getCurrentLocation();
        setUserLocation(location);
      } catch (error) {
        console.error("Error getting location:", error);
      }
    };
    
    fetchLocation();
  }, []);
  
  // Add initial welcome message
  useEffect(() => {
    const welcomeMessage = isArabic 
      ? "مرحباً! أنا المساعد الذكي لصيانة سمارت. يمكنني مساعدتك في:\n\n" +
        "1. العثور على ورش صيانة مناسبة لسيارتك\n" +
        "2. تقديم نصائح حول صيانة السيارات\n" +
        "3. تشخيص مشاكل السيارات\n" +
        "4. تقدير تكاليف الإصلاح\n" +
        "5. المقارنة بين الورش\n\n" +
        "كيف يمكنني مساعدتك اليوم؟"
      : "Hello! I'm the Maintenance Smart AI assistant. I can help you find suitable maintenance workshops, provide advice about your car maintenance, and answer your vehicle-related questions. How can I assist you today?";
    
    setMessages([
      {
        id: "welcome",
        role: "assistant",
        content: welcomeMessage,
        timestamp: new Date()
      }
    ]);
  }, [isArabic]);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  
  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const imageUrl = URL.createObjectURL(file);
      setSelectedImage(imageUrl);
      toast.success(isArabic ? "تم تحميل الصورة" : "Image uploaded");
    }
  };
  
  // Trigger file input click
  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };
  
  // Handle form submission
  const handleSubmit = async () => {
    if (!input.trim() && !selectedImage) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
      location: userLocation || undefined,
      imageUrl: selectedImage || undefined
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    
    try {
      let response;
      
      if (selectedImage) {
        // Use image analysis
        response = await analyzeCarProblemFromImage(input, selectedImage, isArabic);
      } else {
        // Use text-only query
        response = await generateDeepSeekResponse(input, isArabic);
      }
      
      // Add assistant message
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error getting AI response:", error);
      toast.error(isArabic ? "خطأ في الاتصال بالمساعد الذكي" : "Error connecting to AI assistant");
      
      // Add error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: isArabic 
          ? "عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى لاحقاً."
          : "Sorry, there was an error processing your request. Please try again later.",
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      setSelectedImage(null);
    }
  };
  
  // Suggested prompts in Arabic and English
  const suggestedPrompts = [
    {
      text: isArabic ? "ما هي أفضل ورشة لسيارات تويوتا في الرياض؟" : "What's the best workshop for Toyota cars?",
      icon: <Car className="h-4 w-4" />
    },
    {
      text: isArabic ? "متى يجب تغيير زيت المحرك؟" : "When should I change my engine oil?",
      icon: <Wrench className="h-4 w-4" />
    },
    {
      text: isArabic ? "ما هي علامات ضعف بطارية السيارة؟" : "What are signs of a failing battery?",
      icon: <Sparkles className="h-4 w-4" />
    },
    {
      text: isArabic ? "أقرب ورشة صيانة لموقعي الحالي" : "Nearest workshop to my current location",
      icon: <MapPin className="h-4 w-4" />
    }
  ];
  
  // Render map for location-based responses
  const renderMapIfNeeded = (content: string) => {
    if (content.includes("MAP_PLACEHOLDER")) {
      const parts = content.split("MAP_PLACEHOLDER");
      return (
        <>
          {parts[0]}
          <div className="mt-3 mb-3 rounded-lg overflow-hidden h-48 w-full">
            <iframe 
              src={`https://maps.google.com/maps?q=car+repair+Riyadh&z=13&output=embed`}
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
          {parts[1]}
        </>
      );
    }
    return content;
  };
  
  return (
    <div 
      className="min-h-screen flex flex-col"
      dir={dir}
      style={{ fontFamily }}
    >
      {/* Page Header */}
      <div className="pt-24 pb-6 px-6 bg-gray-50">
        <div className="container mx-auto">
          <Link 
            to="/" 
            className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors mb-4"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            {isArabic ? "العودة إلى الرئيسية" : "Back to Home"}
          </Link>
          
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2 flex items-center">
                <Bot className="h-7 w-7 text-primary mr-2" />
                {isArabic ? "المساعد الذكي" : "AI Assistant"}
              </h1>
              <p className="text-muted-foreground">
                {isArabic 
                  ? "احصل على إجابات لأسئلتك حول صيانة السيارات والورش"
                  : "Get answers to your questions about car maintenance and workshops"
                }
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Chat Section */}
      <div className="flex-grow px-6 py-6 bg-gray-50">
        <div className="container mx-auto max-w-4xl">
          <div className="glass-card rounded-xl overflow-hidden shadow-md flex flex-col h-[calc(100vh-250px)] bg-white">
            {/* Messages */}
            <div className="flex-grow p-4 overflow-y-auto">
              {messages.map((message) => (
                <div 
                  key={message.id}
                  className={cn(
                    "mb-4 flex",
                    message.role === "user" ? "justify-end" : "justify-start"
                  )}
                >
                  <div 
                    className={cn(
                      "max-w-[80%] rounded-lg p-4",
                      message.role === "user" 
                        ? "bg-primary text-white rounded-tr-none" 
                        : "bg-white text-gray-800 rounded-tl-none shadow-sm"
                    )}
                  >
                    <div className="flex items-center mb-2">
                      {message.role === "assistant" ? (
                        <>
                          <Bot className="h-5 w-5 mr-2 text-primary" />
                          <span className="text-sm font-medium">
                            {isArabic ? "المساعد الذكي" : "AI Assistant"}
                          </span>
                        </>
                      ) : (
                        <>
                          <User className="h-5 w-5 mr-2 text-white" />
                          <span className="text-sm font-medium">
                            {isArabic ? "أنت" : "You"}
                          </span>
                        </>
                      )}
                      <span className="ml-auto text-xs opacity-70">
                        {message.timestamp.toLocaleTimeString(isArabic ? 'ar-SA' : 'en-US', { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </span>
                    </div>
                    
                    {/* Message content */}
                    <div className="whitespace-pre-wrap text-sm">
                      {message.role === "assistant" 
                        ? renderMapIfNeeded(message.content)
                        : message.content
                      }
                    </div>
                    
                    {/* Display image if present */}
                    {message.imageUrl && (
                      <div className="mt-3">
                        <img 
                          src={message.imageUrl} 
                          alt="Uploaded image" 
                          className="max-w-full rounded-lg max-h-48 object-contain border border-gray-200"
                        />
                      </div>
                    )}
                  </div>
                </div>
              ))}
              
              {/* Loading indicator */}
              {isLoading && (
                <div className="flex justify-start mb-4">
                  <div className="bg-white text-gray-800 rounded-lg rounded-tl-none p-4 max-w-[80%] shadow-sm">
                    <div className="flex items-center">
                      <Loader className="h-5 w-5 text-primary animate-spin mr-2" />
                      <span>
                        {isArabic ? "جاري الكتابة..." : "Typing..."}
                      </span>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Selected image preview */}
              {selectedImage && (
                <div className="flex justify-end mb-4">
                  <div className="bg-gray-200 rounded-lg p-3 max-w-[80%]">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-xs font-medium">
                        {isArabic ? "الصورة المرفقة" : "Attached Image"}
                      </span>
                      <button 
                        onClick={() => setSelectedImage(null)}
                        className="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-gray-300"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                    <img 
                      src={selectedImage} 
                      alt="Selected image" 
                      className="max-w-full rounded-lg max-h-48 object-contain border border-gray-100"
                    />
                  </div>
                </div>
              )}
              
              {/* Scroll anchor */}
              <div ref={messagesEndRef} />
            </div>
            
            {/* Suggested prompts */}
            {messages.length <= 2 && (
              <div className="px-4 py-3 border-t border-gray-200 bg-white">
                <p className="text-sm text-gray-500 mb-2">
                  {isArabic ? "أسئلة مقترحة:" : "Suggested questions:"}
                </p>
                <div className="flex flex-wrap gap-2">
                  {suggestedPrompts.map((prompt, index) => (
                    <button
                      key={index}
                      onClick={() => setInput(prompt.text)}
                      className="flex items-center text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1.5 rounded-full transition-colors"
                    >
                      {prompt.icon}
                      <span className="ml-1.5">{prompt.text}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Hidden file input */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
            
            {/* Input */}
            <div className="p-4 border-t border-gray-200 bg-white">
              <ChatInput
                value={input}
                onChange={setInput}
                onSubmit={handleSubmit}
                onImageUpload={triggerFileInput}
                placeholder={isArabic ? "اكتب رسالتك هنا..." : "Type your message here..."}
                disabled={isLoading}
                hasImage={!!selectedImage}
              />
            </div>
          </div>
          
          {/* Disclaimer */}
          <div className="mt-4 text-center text-xs text-gray-500">
            <p>
              {isArabic 
                ? "المساعد الذكي يقدم معلومات عامة فقط. للحصول على نصائح متخصصة، يرجى استشارة فني مؤهل."
                : "AI Assistant provides general information only. For specialized advice, please consult a qualified technician."
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiAssistant;