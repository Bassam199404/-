import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Car, Mail, Lock, Eye, EyeOff, ArrowRight, Wrench } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { useAuth } from "../contexts/AuthContext";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import { loginUser } from "../services/authService";

const Login = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const { setUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isWorkshopOwner, setIsWorkshopOwner] = useState(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const result = await loginUser(email, password);
      
      if (result.success) {
        setUser(result.user);
        toast.success(isArabic ? "تم تسجيل الدخول بنجاح" : "Login successful");
        
        // Redirect based on user type and previous location
        const from = location.state?.from || (isWorkshopOwner ? '/workshop-owner' : '/');
        navigate(from);
      } else {
        toast.error(result.message || (isArabic ? "فشل تسجيل الدخول" : "Login failed"));
      }
    } catch (error) {
      console.error("Login error:", error);
      toast.error(isArabic ? "حدث خطأ أثناء تسجيل الدخول" : "An error occurred during login");
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div 
      className="min-h-screen flex flex-col"
      dir={dir}
      style={{ fontFamily }}
    >
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=2070&auto=format&fit=crop" 
          alt="Car workshop background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-black/70 mix-blend-multiply"></div>
      </div>
      
      {/* Content */}
      <div className="flex-grow flex items-center justify-center px-6 py-12 relative z-10">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="text-center mb-8">
            <Link to="/" className="inline-flex items-center justify-center">
              <Car className="h-10 w-10 text-white" />
              <span className="text-white text-2xl font-bold ml-2">
                {isArabic ? "صيانة سمارت" : "Maintenance Smart"}
              </span>
            </Link>
          </div>
          
          {/* Login Card */}
          <div className="glass-card rounded-xl p-8 backdrop-blur-md bg-white/90 shadow-xl">
            <h1 className="text-2xl font-bold mb-6 text-center">
              {isArabic ? "تسجيل الدخول" : "Login"}
            </h1>
            
            {/* User Type Toggle */}
            <div className="flex gap-4 mb-6">
              <button
                type="button"
                onClick={() => setIsWorkshopOwner(false)}
                className={cn(
                  "flex-1 py-2 px-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2",
                  !isWorkshopOwner
                    ? "bg-primary text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                <Car className="h-4 w-4" />
                {isArabic ? "مستخدم" : "User"}
              </button>
              <button
                type="button"
                onClick={() => setIsWorkshopOwner(true)}
                className={cn(
                  "flex-1 py-2 px-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2",
                  isWorkshopOwner
                    ? "bg-primary text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                <Wrench className="h-4 w-4" />
                {isArabic ? "صاحب ورشة" : "Workshop Owner"}
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Email Field */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {isArabic ? "البريد الإلكتروني" : "Email"}
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder={isArabic ? "أدخل بريدك الإلكتروني" : "Enter your email"}
                  />
                </div>
              </div>
              
              {/* Password Field */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {isArabic ? "كلمة المرور" : "Password"}
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full pl-10 pr-12 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder={isArabic ? "أدخل كلمة المرور" : "Enter your password"}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>
              
              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className={cn(
                  "w-full py-3 px-4 rounded-lg font-medium text-white transition-colors flex items-center justify-center",
                  isLoading 
                    ? "bg-primary/70 cursor-wait" 
                    : "bg-primary hover:bg-primary/90"
                )}
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    {isArabic ? "جاري تسجيل الدخول..." : "Logging in..."}
                  </>
                ) : (
                  <>
                    {isArabic ? "تسجيل الدخول" : "Login"}
                    <ArrowRight className={cn("h-5 w-5", isArabic ? "mr-2 rotate-180" : "ml-2")} />
                  </>
                )}
              </button>
            </form>
            
            {/* Register Link */}
            <div className="mt-6 text-center text-sm">
              <span className="text-gray-600">
                {isArabic ? "ليس لديك حساب؟" : "Don't have an account?"}
              </span>{" "}
              <Link 
                to="/register" 
                className="text-primary font-medium hover:text-primary/80 transition-colors"
              >
                {isArabic ? "إنشاء حساب" : "Register"}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;