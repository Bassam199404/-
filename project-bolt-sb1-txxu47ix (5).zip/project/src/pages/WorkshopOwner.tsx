import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { toast } from 'sonner';
import { Building2, Dice1 as License, User, Phone, Mail, Clock, MapPin, PenTool as Tool, Wrench, Upload, X, Plus, Save } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { cn } from '../lib/utils';
import {
  registerWorkshopOwner,
  addWorkshopData,
  updateWorkshopData,
  getWorkshopOwnerData,
  uploadWorkshopImages,
  deleteWorkshopImage,
  type WorkshopOwner as IWorkshopOwner,
  type WorkshopData
} from '../services/workshopOwnerService';

const WorkshopOwnerPage = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  
  // State declarations
  const [ownerData, setOwnerData] = useState<Partial<IWorkshopOwner>>({
    business_name: '',
    business_license: '',
    contact_name: '',
    contact_phone: '',
    contact_email: ''
  });
  
  const [workshopData, setWorkshopData] = useState<Partial<WorkshopData>>({
    name: '',
    location: '',
    phone: '',
    hours: '',
    services: [],
    specialties: [],
    images: [],
    description: ''
  });
  
  const [isRegistered, setIsRegistered] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [newService, setNewService] = useState('');
  const [newSpecialty, setNewSpecialty] = useState('');
  
  // Check authentication on mount
  useEffect(() => {
    if (!isAuthenticated || !user) {
      toast.error(isArabic 
        ? 'يجب تسجيل الدخول للوصول إلى هذه الصفحة'
        : 'You must be logged in to access this page'
      );
      navigate('/login', { state: { from: '/workshop-owner' } });
      return;
    }
    
    // Load existing data
    const loadData = async () => {
      try {
        const result = await getWorkshopOwnerData();
        if (result.success && result.data) {
          setIsRegistered(true);
          setOwnerData(result.data);
          if (result.data.workshops) {
            setWorkshopData(result.data.workshops);
          }
        }
      } catch (error) {
        console.error('Error loading data:', error);
        toast.error(isArabic 
          ? 'حدث خطأ أثناء تحميل البيانات'
          : 'Error loading data'
        );
      }
    };
    
    loadData();
  }, [isAuthenticated, user, navigate, isArabic]);
  
  // File upload handling
  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg']
    },
    maxFiles: 5,
    onDrop: async (acceptedFiles) => {
      setIsLoading(true);
      try {
        const result = await uploadWorkshopImages(acceptedFiles);
        if (result.success && result.urls) {
          setWorkshopData(prev => ({
            ...prev,
            images: [...(prev.images || []), ...result.urls]
          }));
          toast.success(isArabic ? 'تم رفع الصور بنجاح' : 'Images uploaded successfully');
        } else {
          throw new Error('Failed to upload images');
        }
      } catch (error) {
        console.error('Error uploading images:', error);
        toast.error(isArabic ? 'فشل رفع الصور' : 'Failed to upload images');
      } finally {
        setIsLoading(false);
      }
    }
  });
  
  // Handle owner registration
  const handleOwnerRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      if (!isAuthenticated) {
        toast.error(isArabic 
          ? 'يجب تسجيل الدخول للمتابعة'
          : 'Please login to continue'
        );
        navigate('/login', { state: { from: '/workshop-owner' } });
        return;
      }
      
      const result = await registerWorkshopOwner(ownerData as IWorkshopOwner);
      if (result.success) {
        setIsRegistered(true);
        toast.success(isArabic ? 'تم التسجيل بنجاح' : 'Registration successful');
      } else {
        throw new Error(result.error || 'Registration failed');
      }
    } catch (error) {
      console.error('Error registering:', error);
      toast.error(isArabic ? 'فشل التسجيل' : 'Registration failed');
    } finally {
      setIsLoading(false);
    }
  };
  
  // Handle workshop data submission
  const handleWorkshopSubmission = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      if (!isAuthenticated) {
        toast.error(isArabic 
          ? 'يجب تسجيل الدخول للمتابعة'
          : 'Please login to continue'
        );
        navigate('/login', { state: { from: '/workshop-owner' } });
        return;
      }
      
      const result = ownerData.workshop_id
        ? await updateWorkshopData(ownerData.workshop_id, workshopData)
        : await addWorkshopData(workshopData as WorkshopData);
      
      if (result.success) {
        toast.success(isArabic ? 'تم حفظ بيانات الورشة بنجاح' : 'Workshop data saved successfully');
        navigate('/workshop-profile');
      } else {
        throw new Error(result.error || 'Failed to save workshop data');
      }
    } catch (error) {
      console.error('Error saving workshop data:', error);
      toast.error(isArabic ? 'فشل حفظ بيانات الورشة' : 'Failed to save workshop data');
    } finally {
      setIsLoading(false);
    }
  };
  
  // Handle image deletion
  const handleImageDelete = async (imageUrl: string) => {
    try {
      const result = await deleteWorkshopImage(imageUrl);
      if (result.success) {
        setWorkshopData(prev => ({
          ...prev,
          images: prev.images?.filter(img => img !== imageUrl)
        }));
        toast.success(isArabic ? 'تم حذف الصورة بنجاح' : 'Image deleted successfully');
      } else {
        throw new Error('Failed to delete image');
      }
    } catch (error) {
      console.error('Error deleting image:', error);
      toast.error(isArabic ? 'فشل حذف الصورة' : 'Failed to delete image');
    }
  };
  
  return (
    <div 
      className="min-h-screen py-24 px-6"
      dir={dir}
      style={{ fontFamily }}
    >
      <div className="container mx-auto max-w-4xl">
        <h1 className="text-3xl font-bold mb-8">
          {isArabic ? 'إدارة الورشة' : 'Workshop Management'}
        </h1>
        
        {!isRegistered ? (
          // Owner Registration Form
          <form onSubmit={handleOwnerRegistration} className="space-y-6">
            <div className="glass-card rounded-xl p-8">
              <h2 className="text-xl font-semibold mb-6">
                {isArabic ? 'تسجيل مالك الورشة' : 'Workshop Owner Registration'}
              </h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'اسم المنشأة' : 'Business Name'}
                  </label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="text"
                      value={ownerData.business_name}
                      onChange={(e) => setOwnerData(prev => ({ ...prev, business_name: e.target.value }))}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'رقم الرخصة التجارية' : 'Business License'}
                  </label>
                  <div className="relative">
                    <License className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="text"
                      value={ownerData.business_license}
                      onChange={(e) => setOwnerData(prev => ({ ...prev, business_license: e.target.value }))}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'اسم المسؤول' : 'Contact Name'}
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="text"
                      value={ownerData.contact_name}
                      onChange={(e) => setOwnerData(prev => ({ ...prev, contact_name: e.target.value }))}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'رقم الهاتف' : 'Contact Phone'}
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="tel"
                      value={ownerData.contact_phone}
                      onChange={(e) => setOwnerData(prev => ({ ...prev, contact_phone: e.target.value }))}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'البريد الإلكتروني' : 'Contact Email'}
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="email"
                      value={ownerData.contact_email}
                      onChange={(e) => setOwnerData(prev => ({ ...prev, contact_email: e.target.value }))}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
              </div>
              
              <button
                type="submit"
                disabled={isLoading}
                className={cn(
                  "w-full mt-6 py-3 rounded-lg font-medium text-white transition-colors",
                  isLoading ? "bg-primary/70" : "bg-primary hover:bg-primary/90"
                )}
              >
                {isLoading 
                  ? (isArabic ? 'جاري التسجيل...' : 'Registering...')
                  : (isArabic ? 'تسجيل' : 'Register')
                }
              </button>
            </div>
          </form>
        ) : (
          // Workshop Data Form
          <form onSubmit={handleWorkshopSubmission} className="space-y-6">
            <div className="glass-card rounded-xl p-8">
              <h2 className="text-xl font-semibold mb-6">
                {isArabic ? 'بيانات الورشة' : 'Workshop Information'}
              </h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'اسم الورشة' : 'Workshop Name'}
                  </label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="text"
                      value={workshopData.name}
                      onChange={(e) => setWorkshopData(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'الموقع' : 'Location'}
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="text"
                      value={workshopData.location}
                      onChange={(e) => setWorkshopData(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'رقم الهاتف' : 'Phone'}
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="tel"
                      value={workshopData.phone}
                      onChange={(e) => setWorkshopData(prev => ({ ...prev, phone: e.target.value }))}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'ساعات العمل' : 'Working Hours'}
                  </label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="text"
                      value={workshopData.hours}
                      onChange={(e) => setWorkshopData(prev => ({ ...prev, hours: e.target.value }))}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                      required
                      placeholder={isArabic ? "مثال: 8:00 ص - 8:00 م" : "e.g. 8:00 AM - 8:00 PM"}
                    />
                  </div>
                </div>
                
                {/* Services */}
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'الخدمات' : 'Services'}
                  </label>
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <div className="relative flex-grow">
                        <Tool className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <input
                          type="text"
                          value={newService}
                          onChange={(e) => setNewService(e.target.value)}
                          className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                          placeholder={isArabic ? "أضف خدمة جديدة" : "Add new service"}
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          if (newService.trim()) {
                            setWorkshopData(prev => ({
                              ...prev,
                              services: [...(prev.services || []), newService.trim()]
                            }));
                            setNewService('');
                          }
                        }}
                        className="p-2 rounded-lg bg-primary text-white hover:bg-primary/90"
                      >
                        <Plus className="h-5 w-5" />
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {workshopData.services?.map((service, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-1 bg-gray-100 px-3 py-1 rounded-full"
                        >
                          <span className="text-sm">{service}</span>
                          <button
                            type="button"
                            onClick={() => setWorkshopData(prev => ({
                              ...prev,
                              services: prev.services?.filter((_, i) => i !== index)
                            }))}
                            className="p-1 hover:text-red-500"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                {/* Specialties */}
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'التخصصات' : 'Specialties'}
                  </label>
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <div className="relative flex-grow">
                        <Wrench className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <input
                          type="text"
                          value={newSpecialty}
                          onChange={(e) => setNewSpecialty(e.target.value)}
                          className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                          placeholder={isArabic ? "أضف تخصص جديد" : "Add new specialty"}
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          if (newSpecialty.trim()) {
                            setWorkshopData(prev => ({
                              ...prev,
                              specialties: [...(prev.specialties || []), newSpecialty.trim()]
                            }));
                            setNewSpecialty('');
                          }
                        }}
                        className="p-2 rounded-lg bg-primary text-white hover:bg-primary/90"
                      >
                        <Plus className="h-5 w-5" />
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {workshopData.specialties?.map((specialty, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-1 bg-gray-100 px-3 py-1 rounded-full"
                        >
                          <span className="text-sm">{specialty}</span>
                          <button
                            type="button"
                            onClick={() => setWorkshopData(prev => ({
                              ...prev,
                              specialties: prev.specialties?.filter((_, i) => i !== index)
                            }))}
                            className="p-1 hover:text-red-500"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                {/* Images */}
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'صور الورشة' : 'Workshop Images'}
                  </label>
                  <div 
                    {...getRootProps()} 
                    className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors"
                  >
                    <input {...getInputProps()} />
                    <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-500">
                      {isArabic 
                        ? 'اسحب وأفلت الصور هنا، أو انقر للاختيار'
                        : 'Drag & drop images here, or click to select'
                      }
                    </p>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-4">
                    {workshopData.images?.map((image, index) => (
                      <div key={index} className="relative">
                        <img
                          src={image}
                          alt={`Workshop ${index + 1}`}
                          className="w-full h-32 object-cover rounded-lg"
                        />
                        <button
                          type="button"
                          onClick={() => handleImageDelete(image)}
                          className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Description */}
                <div>
                  <label className="block text-sm font-medium mb-1">
                    {isArabic ? 'وصف الورشة' : 'Workshop Description'}
                  </label>
                  <textarea
                    value={workshopData.description}
                    onChange={(e) => setWorkshopData(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary"
                    rows={4}
                    required
                  />
                </div>
              </div>
              
              <button
                type="submit"
                disabled={isLoading}
                className={cn(
                  "w-full mt-6 py-3 rounded-lg font-medium text-white transition-colors flex items-center justify-center gap-2",
                  isLoading ? "bg-primary/70" : "bg-primary hover:bg-primary/90"
                )}
              >
                <Save className="h-5 w-5" />
                {isLoading 
                  ? (isArabic ? 'جاري الحفظ...' : 'Saving...')
                  : (isArabic ? 'حفظ بيانات الورشة' : 'Save Workshop Data')
                }
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default WorkshopOwnerPage;