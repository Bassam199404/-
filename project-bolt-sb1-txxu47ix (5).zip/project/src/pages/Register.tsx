import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Car, Mail, Lock, User, Eye, EyeOff, ArrowRight, Phone, Wrench, Building2, Dice1 as License } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import { registerUser } from "../services/authService";
import { registerWorkshopOwner } from "../services/workshopOwnerService";

const Register = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const navigate = useNavigate();
  
  // Common fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  
  // Workshop owner fields
  const [isWorkshopOwner, setIsWorkshopOwner] = useState(false);
  const [businessName, setBusinessName] = useState("");
  const [businessLicense, setBusinessLicense] = useState("");
  
  // UI state
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate passwords match
    if (password !== confirmPassword) {
      toast.error(isArabic ? "كلمات المرور غير متطابقة" : "Passwords do not match");
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Register user first
      const userResult = await registerUser(
        name,
        email,
        phone,
        password,
        isWorkshopOwner ? 'workshop_owner' : 'user'
      );
      
      if (!userResult.success) {
        throw new Error(userResult.message);
      }

      // If workshop owner, register workshop owner details
      if (isWorkshopOwner) {
        const ownerResult = await registerWorkshopOwner({
          business_name: businessName,
          business_license: businessLicense,
          contact_name: name,
          contact_phone: phone,
          contact_email: email
        });

        if (!ownerResult.success) {
          throw new Error('Failed to register workshop owner details');
        }
      }

      toast.success(isArabic ? "تم إنشاء الحساب بنجاح" : "Account created successfully");
      navigate("/login");
    } catch (error) {
      console.error("Registration error:", error);
      toast.error(isArabic ? "حدث خطأ أثناء إنشاء الحساب" : "An error occurred during registration");
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div 
      className="min-h-screen flex flex-col"
      dir={dir}
      style={{ fontFamily }}
    >
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=2070&auto=format&fit=crop" 
          alt="Car workshop background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-black/70 mix-blend-multiply"></div>
      </div>
      
      {/* Content */}
      <div className="flex-grow flex items-center justify-center px-6 py-12 relative z-10">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="text-center mb-8">
            <Link to="/" className="inline-flex items-center justify-center">
              <Car className="h-10 w-10 text-white" />
              <span className="text-white text-2xl font-bold ml-2">
                {isArabic ? "صيانة سمارت" : "Maintenance Smart"}
              </span>
            </Link>
          </div>
          
          {/* Register Card */}
          <div className="glass-card rounded-xl p-8 backdrop-blur-md bg-white/90 shadow-xl">
            <h1 className="text-2xl font-bold mb-6 text-center">
              {isArabic ? "إنشاء حساب جديد" : "Create Account"}
            </h1>
            
            {/* User Type Toggle */}
            <div className="flex gap-4 mb-6">
              <button
                type="button"
                onClick={() => setIsWorkshopOwner(false)}
                className={cn(
                  "flex-1 py-2 px-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2",
                  !isWorkshopOwner
                    ? "bg-primary text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                <Car className="h-4 w-4" />
                {isArabic ? "مستخدم" : "User"}
              </button>
              <button
                type="button"
                onClick={() => setIsWorkshopOwner(true)}
                className={cn(
                  "flex-1 py-2 px-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2",
                  isWorkshopOwner
                    ? "bg-primary text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                )}
              >
                <Wrench className="h-4 w-4" />
                {isArabic ? "صاحب ورشة" : "Workshop Owner"}
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Workshop Owner Fields */}
              {isWorkshopOwner && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {isArabic ? "اسم المنشأة" : "Business Name"}
                    </label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <input
                        type="text"
                        value={businessName}
                        onChange={(e) => setBusinessName(e.target.value)}
                        required={isWorkshopOwner}
                        className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder={isArabic ? "أدخل اسم المنشأة" : "Enter business name"}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {isArabic ? "رقم الرخصة التجارية" : "Business License"}
                    </label>
                    <div className="relative">
                      <License className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <input
                        type="text"
                        value={businessLicense}
                        onChange={(e) => setBusinessLicense(e.target.value)}
                        required={isWorkshopOwner}
                        className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder={isArabic ? "أدخل رقم الرخصة التجارية" : "Enter business license number"}
                      />
                    </div>
                  </div>
                </>
              )}
              
              {/* Common Fields */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {isArabic ? "الاسم" : "Name"}
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder={isArabic ? "أدخل اسمك الكامل" : "Enter your full name"}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {isArabic ? "البريد الإلكتروني" : "Email"}
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder={isArabic ? "أدخل بريدك الإلكتروني" : "Enter your email"}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {isArabic ? "رقم الهاتف" : "Phone Number"}
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder={isArabic ? "أدخل رقم هاتفك" : "Enter your phone number"}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {isArabic ? "كلمة المرور" : "Password"}
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={6}
                    className="w-full pl-10 pr-12 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder={isArabic ? "أدخل كلمة المرور" : "Enter your password"}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {isArabic ? "يجب أن تتكون كلمة المرور من 6 أحرف على الأقل" : "Password must be at least 6 characters"}
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {isArabic ? "تأكيد كلمة المرور" : "Confirm Password"}
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    className="w-full pl-10 pr-12 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder={isArabic ? "أعد إدخال كلمة المرور" : "Re-enter your password"}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    aria-label={showConfirmPassword ? "Hide password" : "Show password"}
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>
              
              {/* Terms and Conditions */}
              <div className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    id="terms"
                    type="checkbox"
                    required
                    className="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary"
                  />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor="terms" className="text-gray-600">
                    {isArabic 
                      ? "أوافق على شروط الخدمة وسياسة الخصوصية" 
                      : "I agree to the Terms of Service and Privacy Policy"}
                  </label>
                </div>
              </div>
              
              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className={cn(
                  "w-full py-3 px-4 rounded-lg font-medium text-white transition-colors flex items-center justify-center",
                  isLoading 
                    ? "bg-primary/70 cursor-wait" 
                    : "bg-primary hover:bg-primary/90"
                )}
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    {isArabic ? "جاري إنشاء الحساب..." : "Creating account..."}
                  </>
                ) : (
                  <>
                    {isArabic ? "إنشاء حساب" : "Create Account"}
                    <ArrowRight className={cn("h-5 w-5", isArabic ? "mr-2 rotate-180" : "ml-2")} />
                  </>
                )}
              </button>
            </form>
            
            {/* Login Link */}
            <div className="mt-6 text-center text-sm">
              <span className="text-gray-600">
                {isArabic ? "لديك حساب بالفعل؟" : "Already have an account?"}
              </span>{" "}
              <Link 
                to="/login" 
                className="text-primary font-medium hover:text-primary/80 transition-colors"
              >
                {isArabic ? "تسجيل الدخول" : "Login"}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;