import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import WorkshopCard from "../components/WorkshopCard";
import ComparisonModal from "../components/ComparisonModal";
import { ChevronLeft, SlidersHorizontal } from "lucide-react";
import { cn } from "../lib/utils";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner";
import { getWorkshops, searchWorkshops, getWorkshopsByIds, Workshop } from "../services/workshopService";
import SearchInput from "../components/SearchInput";

const CompareWorkshops = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedWorkshops, setSelectedWorkshops] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filtersVisible, setFiltersVisible] = useState(false);
  const [isComparing, setIsComparing] = useState(false);
  const [sortBy, setSortBy] = useState<'rating' | 'distance' | 'name'>('rating');
  
  // Scroll to top on page load
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  // Load workshops on initial render
  useEffect(() => {
    const loadWorkshops = async () => {
      setLoading(true);
      try {
        const data = await getWorkshops();
        setWorkshops(data);
      } catch (error) {
        console.error("Error loading workshops:", error);
        toast.error(isArabic ? "حدث خطأ أثناء تحميل الورش" : "Error loading workshops");
      } finally {
        setLoading(false);
      }
    };
    
    loadWorkshops();
  }, [isArabic]);
  
  // Filter workshops based on search term
  useEffect(() => {
    const performSearch = async () => {
      if (searchTerm.trim() === "") {
        // If search is cleared, reload all workshops
        const data = await getWorkshops();
        setWorkshops(data);
        return;
      }
      
      setLoading(true);
      try {
        const results = await searchWorkshops(searchTerm);
        setWorkshops(results);
      } catch (error) {
        console.error("Error searching workshops:", error);
      } finally {
        setLoading(false);
      }
    };
    
    // Debounce search to avoid too many requests
    const timer = setTimeout(() => {
      performSearch();
    }, 300);
    
    return () => clearTimeout(timer);
  }, [searchTerm]);
  
  // Sort workshops
  useEffect(() => {
    const sortedWorkshops = [...workshops];
    
    if (sortBy === 'rating') {
      sortedWorkshops.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'distance') {
      sortedWorkshops.sort((a, b) => {
        const distanceA = parseFloat(a.distance.replace(' km', ''));
        const distanceB = parseFloat(b.distance.replace(' km', ''));
        return distanceA - distanceB;
      });
    } else if (sortBy === 'name') {
      sortedWorkshops.sort((a, b) => a.name.localeCompare(b.name));
    }
    
    setWorkshops(sortedWorkshops);
  }, [sortBy, workshops.length]);
  
  // Toggle workshop selection
  const toggleWorkshopSelection = (id: string) => {
    if (selectedWorkshops.includes(id)) {
      setSelectedWorkshops(selectedWorkshops.filter(workshopId => workshopId !== id));
    } else {
      // Limit to 3 selections
      if (selectedWorkshops.length < 3) {
        setSelectedWorkshops([...selectedWorkshops, id]);
      } else {
        toast.info(isArabic ? "يمكنك اختيار 3 ورش كحد أقصى للمقارنة" : "You can select up to 3 workshops for comparison");
      }
    }
  };
  
  // Get selected workshops data
  const getSelectedWorkshopsData = async () => {
    if (selectedWorkshops.length === 0) return [];
    
    try {
      return await getWorkshopsByIds(selectedWorkshops);
    } catch (error) {
      console.error("Error getting selected workshops:", error);
      // Fallback to filtering from current workshops
      return workshops.filter(workshop => selectedWorkshops.includes(workshop.id));
    }
  };
  
  return (
    <div 
      className="min-h-screen flex flex-col"
      dir={dir}
      style={{ fontFamily }}
    >
      {/* Page Header */}
      <div className="pt-24 pb-12 px-6">
        <div className="container mx-auto">
          <Link 
            to="/" 
            className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            {isArabic ? "العودة إلى الرئيسية" : "Back to Home"}
          </Link>
          
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              {isArabic ? "مقارنة الورش" : "Compare Workshops"}
            </h1>
            <p className="text-muted-foreground mb-8">
              {isArabic 
                ? "تصفح وقارن بين ورش العمل المختلفة للعثور على أفضل خدمة لسيارتك. حدد ما يصل إلى 3 ورش عمل للمقارنة بين خدماتها وأسعارها."
                : "Browse and compare different workshops to find the best service for your vehicle. Select up to 3 workshops to compare their services and prices."
              }
            </p>
            
            {/* Search & Filter */}
            <div className="glass-card p-4 rounded-xl">
              <div className="flex flex-col md:flex-row gap-4">
                <SearchInput
                  value={searchTerm}
                  onChange={setSearchTerm}
                  placeholder={isArabic ? "البحث بالاسم أو التخصص أو الموقع" : "Search by name, specialty, or location"}
                  className="flex-grow"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setFiltersVisible(!filtersVisible)}
                  className={cn(
                    "inline-flex items-center px-4 py-2 rounded-lg transition-colors",
                    filtersVisible
                      ? "bg-primary text-white"
                      : "bg-secondary text-foreground hover:bg-secondary/70"
                  )}
                >
                  <SlidersHorizontal className="h-4 w-4 mr-2" />
                  {isArabic ? "الفلاتر" : "Filters"}
                </button>
              </div>
              
              {/* Filters Panel */}
              {filtersVisible && (
                <div className="mt-4 pt-4 border-t border-border grid grid-cols-1 md:grid-cols-3 gap-4 animate-fade-in">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {isArabic ? "نوع الخدمة" : "Service Type"}
                    </label>
                    <select className="w-full px-3 py-2 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all">
                      <option value="">{isArabic ? "جميع الخدمات" : "All Services"}</option>
                      <option value="oil">{isArabic ? "تغيير الزيت" : "Oil Change"}</option>
                      <option value="brake">{isArabic ? "خدمة الفرامل" : "Brake Service"}</option>
                      <option value="engine">{isArabic ? "إصلاح المحرك" : "Engine Repair"}</option>
                      <option value="body">{isArabic ? "أعمال الهيكل" : "Body Work"}</option>
                      <option value="tire">{isArabic ? "خدمة الإطارات" : "Tire Service"}</option>
                      <option value="ac">{isArabic ? "خدمة التكييف" : "A/C Service"}</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {isArabic ? "التقييم" : "Rating"}
                    </label>
                    <select className="w-full px-3 py-2 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all">
                      <option value="">{isArabic ? "أي تقييم" : "Any Rating"}</option>
                      <option value="4.5">{isArabic ? "4.5 وما فوق" : "4.5 & Above"}</option>
                      <option value="4">{isArabic ? "4.0 وما فوق" : "4.0 & Above"}</option>
                      <option value="3.5">{isArabic ? "3.5 وما فوق" : "3.5 & Above"}</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {isArabic ? "المسافة" : "Distance"}
                    </label>
                    <select className="w-full px-3 py-2 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all">
                      <option value="">{isArabic ? "أي مسافة" : "Any Distance"}</option>
                      <option value="5">{isArabic ? "ضمن 5 كم" : "Within 5 km"}</option>
                      <option value="10">{isArabic ? "ضمن 10 كم" : "Within 10 km"}</option>
                      <option value="15">{isArabic ? "ضمن 15 كم" : "Within 15 km"}</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Selected Workshops Bar */}
      {selectedWorkshops.length > 0 && (
        <div className="sticky top-16 z-40 bg-primary/90 text-white px-6 py-3 backdrop-blur-md animate-fade-in">
          <div className="container mx-auto flex flex-col sm:flex-row items-center justify-between">
            <div className="flex items-center mb-3 sm:mb-0">
              <span className="font-medium mr-3">
                {selectedWorkshops.length} {selectedWorkshops.length === 1 
                  ? (isArabic ? 'ورشة محددة' : 'workshop selected') 
                  : (isArabic ? 'ورش محددة' : 'workshops selected')
                }
              </span>
              <div className="flex -space-x-2">
                {selectedWorkshops.map((id) => {
                  const workshop = workshops.find(w => w.id === id);
                  return workshop ? (
                    <div key={id} className="w-8 h-8 rounded-full overflow-hidden border-2 border-white">
                      <img 
                        src={workshop.image} 
                        alt={workshop.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : null;
                })}
              </div>
            </div>
            
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setSelectedWorkshops([])}
                className="px-3 py-1 text-xs font-medium bg-white/10 hover:bg-white/20 rounded-md transition-colors"
              >
                {isArabic ? "مسح" : "Clear"}
              </button>
              <button
                type="button"
                onClick={() => setIsComparing(true)}
                className="px-4 py-1 text-sm font-medium bg-white text-primary rounded-md hover:bg-white/90 transition-colors"
              >
                {isArabic ? "مقارنة المحدد" : "Compare Selected"}
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Workshops List */}
      <div className="flex-grow px-6 py-12">
        <div className="container mx-auto">
          {loading ? (
            <div className="text-center py-20">
              <div className="inline-block animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
              <p className="text-muted-foreground">
                {isArabic ? "جاري تحميل الورش..." : "Loading workshops..."}
              </p>
            </div>
          ) : workshops.length === 0 ? (
            <div className="text-center py-20">
              <h3 className="text-xl font-medium mb-2">
                {isArabic ? "لم يتم العثور على ورش" : "No workshops found"}
              </h3>
              <p className="text-muted-foreground">
                {isArabic 
                  ? "حاول تعديل البحث أو الفلاتر للعثور على ورش."
                  : "Try adjusting your search or filters to find workshops."
                }
              </p>
            </div>
          ) : (
            <>
              <div className="mb-6 flex justify-between items-center">
                <p className="text-muted-foreground">
                  {isArabic 
                    ? `عرض ${workshops.length} ورشة في الرياض`
                    : `Showing ${workshops.length} workshops in Riyadh`
                  }
                </p>
                <select 
                  className="px-3 py-1 rounded-lg border border-input bg-background text-sm"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as 'rating' | 'distance' | 'name')}
                >
                  <option value="rating">{isArabic ? "ترتيب حسب: التقييم" : "Sort by: Rating"}</option>
                  <option value="distance">{isArabic ? "ترتيب حسب: المسافة" : "Sort by: Distance"}</option>
                  <option value="name">{isArabic ? "ترتيب حسب: الاسم" : "Sort by: Name"}</option>
                </select>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {workshops.map((workshop) => (
                  <WorkshopCard
                    key={workshop.id}
                    id={workshop.id}
                    name={workshop.name}
                    rating={workshop.rating}
                    reviewCount={workshop.review_count}
                    image={workshop.image}
                    location={workshop.location}
                    distance={workshop.distance}
                    hours={workshop.hours}
                    phone={workshop.phone}
                    services={workshop.services}
                    specialties={workshop.specialties}
                    isSelected={selectedWorkshops.includes(workshop.id)}
                    onSelect={() => toggleWorkshopSelection(workshop.id)}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
      
      {/* Comparison Modal */}
      {isComparing && (
        <ComparisonModal 
          open={isComparing && selectedWorkshops.length > 0} 
          onClose={() => setIsComparing(false)}
          workshops={workshops.filter(w => selectedWorkshops.includes(w.id))}
        />
      )}
    </div>
  );
};

export default CompareWorkshops;