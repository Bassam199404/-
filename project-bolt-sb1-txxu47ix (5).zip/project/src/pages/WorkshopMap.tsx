import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ChevronLeft, List, Map as MapIcon } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { cn } from "../lib/utils";
import MapView from "../components/MapView";
import WorkshopCard from "../components/WorkshopCard";
import { getWorkshops, Workshop } from "../services/workshopService";
import { getCurrentLocation, Location } from "../services/mapsService";
import { toast } from "sonner";
import SearchInput from "../components/SearchInput";

const WorkshopMap = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [loading, setLoading] = useState(true);
  const [userLocation, setUserLocation] = useState<Location | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const [selectedWorkshop, setSelectedWorkshop] = useState<Workshop | null>(null);
  
  // Load workshops and user location
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        // Get user location
        const location = await getCurrentLocation();
        setUserLocation(location);
        
        // Get workshops
        const workshopsData = await getWorkshops();
        
        // Add mock coordinates for demo purposes
        // In a real app, these would come from the database
        const workshopsWithLocation = workshopsData.map((workshop, index) => ({
          ...workshop,
          location_lat: 24.7136 + (Math.random() * 0.1 - 0.05), // Random coordinates around Riyadh
          location_lng: 46.6753 + (Math.random() * 0.1 - 0.05)
        }));
        
        setWorkshops(workshopsWithLocation);
      } catch (error) {
        console.error("Error loading data:", error);
        toast.error(isArabic ? "حدث خطأ أثناء تحميل البيانات" : "Error loading data");
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, [isArabic]);
  
  // Filter workshops based on search term
  const filteredWorkshops = workshops.filter(workshop => 
    searchTerm === "" || 
    workshop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    workshop.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    workshop.specialties.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  
  // Handle workshop selection from map
  const handleWorkshopSelect = (workshop: Workshop) => {
    setSelectedWorkshop(workshop);
    
    // If in mobile view, switch to list view to show details
    if (window.innerWidth < 768 && viewMode === 'map') {
      setViewMode('list');
    }
  };
  
  return (
    <div 
      className="min-h-screen flex flex-col"
      dir={dir}
      style={{ fontFamily }}
    >
      {/* Page Header */}
      <div className="pt-24 pb-6 px-6 bg-gray-50">
        <div className="container mx-auto">
          <Link 
            to="/" 
            className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors mb-4"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            {isArabic ? "العودة إلى الرئيسية" : "Back to Home"}
          </Link>
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2">
                {isArabic ? "ورش الصيانة على الخريطة" : "Workshops on Map"}
              </h1>
              <p className="text-muted-foreground">
                {isArabic 
                  ? "استكشف ورش الصيانة القريبة منك على الخريطة"
                  : "Explore maintenance workshops near you on the map"
                }
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <SearchInput
                value={searchTerm}
                onChange={setSearchTerm}
                placeholder={isArabic ? "البحث عن ورشة..." : "Search for a workshop..."}
                className="flex-grow"
              />
              
              {/* View toggle (mobile only) */}
              <div className="md:hidden flex items-center bg-secondary rounded-lg p-1">
                <button
                  type="button"
                  onClick={() => setViewMode('map')}
                  className={cn(
                    "p-2 rounded",
                    viewMode === 'map' ? "bg-white text-primary shadow-sm" : "text-muted-foreground"
                  )}
                  aria-label="Map view"
                >
                  <MapIcon className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('list')}
                  className={cn(
                    "p-2 rounded",
                    viewMode === 'list' ? "bg-white text-primary shadow-sm" : "text-muted-foreground"
                  )}
                  aria-label="List view"
                >
                  <List className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Map and List Section */}
      <div className="flex-grow px-6 py-6">
        <div className="container mx-auto">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              <span className="ml-3 text-muted-foreground">
                {isArabic ? "جاري التحميل..." : "Loading..."}
              </span>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Workshop List (desktop: left column, mobile: conditionally shown) */}
              <div 
                className={cn(
                  "md:col-span-1 overflow-y-auto",
                  viewMode === 'list' || window.innerWidth >= 768 ? "block" : "hidden"
                )}
                style={{ maxHeight: "calc(100vh - 200px)" }}
              >
                <h2 className="text-lg font-semibold mb-4">
                  {isArabic 
                    ? `${filteredWorkshops.length} ورشة متاحة`
                    : `${filteredWorkshops.length} Available Workshops`
                  }
                </h2>
                
                <div className="space-y-4">
                  {filteredWorkshops.length === 0 ? (
                    <div className="text-center py-8 bg-gray-50 rounded-lg">
                      <MapIcon className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
                      <p className="text-muted-foreground">
                        {isArabic 
                          ? "لم يتم العثور على ورش مطابقة"
                          : "No matching workshops found"
                        }
                      </p>
                    </div>
                  ) : (
                    filteredWorkshops.map(workshop => (
                      <div 
                        key={workshop.id}
                        className={cn(
                          "cursor-pointer transition-all",
                          selectedWorkshop?.id === workshop.id ? "ring-2 ring-primary rounded-xl" : ""
                        )}
                        onClick={() => setSelectedWorkshop(workshop)}
                      >
                        <WorkshopCard
                          id={workshop.id}
                          name={workshop.name}
                          rating={workshop.rating}
                          reviewCount={workshop.review_count}
                          image={workshop.image}
                          location={workshop.location}
                          distance={workshop.distance}
                          hours={workshop.hours}
                          phone={workshop.phone}
                          services={workshop.services}
                          specialties={workshop.specialties}
                          isSelected={selectedWorkshop?.id === workshop.id}
                          onSelect={() => setSelectedWorkshop(workshop)}
                        />
                      </div>
                    ))
                  )}
                </div>
              </div>
              
              {/* Map (desktop: right column, mobile: conditionally shown) */}
              <div 
                className={cn(
                  "md:col-span-2",
                  viewMode === 'map' || window.innerWidth >= 768 ? "block" : "hidden"
                )}
              >
                <div className="h-[calc(100vh-200px)] w-full rounded-lg overflow-hidden shadow-md">
                  <MapView
                    workshops={filteredWorkshops}
                    onWorkshopSelect={handleWorkshopSelect}
                    height="100%"
                    width="100%"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WorkshopMap;