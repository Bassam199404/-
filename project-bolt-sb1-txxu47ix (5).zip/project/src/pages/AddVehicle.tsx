import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import VehicleForm from "../components/VehicleForm";
import { ChevronLeft } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";

const AddVehicle = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  
  // Scroll to top on page load
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  return (
    <div className="min-h-screen flex flex-col">
      {/* Page Header */}
      <div className="pt-24 pb-12 px-6">
        <div className="container mx-auto">
          <Link 
            to="/" 
            className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            {isArabic ? "العودة إلى الرئيسية" : "Back to Home"}
          </Link>
          
          <div className="text-center max-w-2xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              {isArabic ? "معلومات المركبة" : "Vehicle Information"}
            </h1>
            <p className="text-muted-foreground">
              {isArabic 
                ? "قدم تفاصيل عن مركبتك للحصول على عروض أسعار دقيقة والعثور على الورش الأنسب."
                : "Provide details about your vehicle to receive accurate service quotes and find the most suitable workshops."
              }
            </p>
          </div>
        </div>
      </div>
      
      {/* Form Section */}
      <div className="flex-grow px-6 pb-20">
        <div className="container mx-auto">
          <VehicleForm />
          
          <div className="mt-10 text-center text-sm text-muted-foreground max-w-2xl mx-auto" dir={dir} style={{ fontFamily }}>
            <p>
              {isArabic 
                ? "بتقديم معلومات مركبتك، فإنك توافق على شروط الخدمة وسياسة الخصوصية الخاصة بنا. لن تتم مشاركة معلوماتك إلا مع الورش التي تختار تلقي عروض أسعار منها."
                : "By submitting your vehicle information, you agree to our Terms of Service and Privacy Policy. Your information will only be shared with workshops you choose to receive quotes from."
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddVehicle;