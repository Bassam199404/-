import React, { useEffect } from "react";
import Hero from "../components/Hero";
import ServiceCard from "../components/ServiceCard";
import AiFeatures from "../components/AiFeatures";
import { Link } from "react-router-dom";
import { Wrench, CarFront, PenToolIcon as ToolIcon, Search, Shield, Star, ArrowRight } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import Nav from "../components/Nav";
import { cn } from "../lib/utils";

const Index = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  
  // Scroll to top on page load
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Sample workshop data for display
  const featuredWorkshops = [
    {
      id: 1,
      name: isArabic ? "مركز الفيصل للسيارات" : "Al-Faisal Auto Center",
      rating: 4.8,
      specialty: isArabic ? "متخصص تويوتا ولكزس" : "Toyota & Lexus Specialist",
      image: "https://images.unsplash.com/photo-1540066019607-e5f69323a8dc?q=80&w=1000&auto=format&fit=crop"
    },
    {
      id: 2,
      name: isArabic ? "ورشة الرياض للسيارات" : "Riyadh Motors",
      rating: 4.6,
      specialty: isArabic ? "إصلاحات عامة" : "General Repairs",
      image: "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=1000&auto=format&fit=crop"
    },
    {
      id: 3,
      name: isArabic ? "ورشة السعود" : "Al-Saud Workshop",
      rating: 4.7,
      specialty: isArabic ? "إصلاح حوادث" : "Accident Repairs",
      image: "https://images.unsplash.com/photo-1583121274602-3e2820c69888?q=80&w=1000&auto=format&fit=crop"
    }
  ];
  
  return (
    <div 
      className="min-h-screen flex flex-col relative"
      dir={dir}
      style={{ fontFamily }}
    >
      {/* Full page background image with overlay */}
      <div className="fixed inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=2070&auto=format&fit=crop" 
          alt="Car workshop background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-black/70 mix-blend-multiply"></div>
      </div>
      
      {/* Navigation */}
      <Nav />
      
      {/* Hero Section */}
      <Hero />
      
      {/* AI Features Section */}
      <AiFeatures />
      
      {/* Services Section */}
      <section className="py-20 px-6 relative">
        {/* Section-specific overlay */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-white/80"></div>
        </div>
        
        <div className="container mx-auto relative z-10">
          <div className="text-center mb-16">
            <div className="inline-block px-3 py-1 mb-4 text-xs font-medium text-primary bg-primary/10 rounded-full">
              {isArabic ? "خدماتنا" : "Our Services"}
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {isArabic ? "حلول شاملة للعناية بالسيارات" : "Comprehensive Car Care Solutions"}
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              {isArabic 
                ? "من الصيانة الروتينية إلى الإصلاحات المعقدة، تواصل مع المتخصصين الذين يمكنهم التعامل مع جميع احتياجات سيارتك."
                : "From routine maintenance to complex repairs, connect with specialists who can handle all your vehicle needs."
              }
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ServiceCard 
              title={isArabic ? "الصيانة الدورية" : "Regular Maintenance"}
              description={isArabic 
                ? "جدولة الخدمات الروتينية مثل تغيير الزيت واستبدال الفلاتر والفحوصات مع ورش معتمدة."
                : "Schedule routine services like oil changes, filter replacements, and inspections with certified workshops."
              }
              icon={<Wrench className="h-6 w-6 text-primary" />}
              delay={100}
            />
            <ServiceCard 
              title={isArabic ? "إصلاح الحوادث" : "Accident Repairs"}
              description={isArabic 
                ? "ابحث عن ورش متخصصة في إصلاح هياكل السيارات وإزالة الخدوش وأعمال الطلاء."
                : "Find specialized body shops and mechanics for collision damage, dent removal, and paint work."
              }
              icon={<CarFront className="h-6 w-6 text-primary" />}
              delay={200}
            />
            <ServiceCard 
              title={isArabic ? "قطع الغيار" : "Spare Parts"}
              description={isArabic 
                ? "تواصل مع موردين موثوقين يقدمون قطع غيار أصلية لجميع أنواع وموديلات السيارات."
                : "Connect with trusted suppliers offering genuine and OEM parts for all vehicle makes and models."
              }
              icon={<ToolIcon className="h-6 w-6 text-primary" />}
              delay={300}
            />
            <ServiceCard 
              title={isArabic ? "البحث عن ورشة" : "Find Workshop"}
              description={isArabic 
                ? "ابحث وصفّي الورش حسب الموقع والتخصصات والتقييمات والتوافر."
                : "Search and filter workshops based on location, specialties, ratings, and availability."
              }
              icon={<Search className="h-6 w-6 text-primary" />}
              delay={400}
            />
            <ServiceCard 
              title={isArabic ? "خدمات الضمان" : "Warranty Services"}
              description={isArabic 
                ? "احصل على خدمة سيارتك في المراكز المعتمدة للحفاظ على تغطية الضمان الخاص بك."
                : "Get your vehicle serviced at authorized centers to maintain your warranty coverage."
              }
              icon={<Shield className="h-6 w-6 text-primary" />}
              delay={500}
            />
            <ServiceCard 
              title={isArabic ? "تقييمات الورش" : "Workshop Reviews"}
              description={isArabic 
                ? "اتخذ قرارات مستنيرة من خلال قراءة التقييمات والتصنيفات الحقيقية من مالكي السيارات الآخرين."
                : "Make informed decisions by reading authentic reviews and ratings from other vehicle owners."
              }
              icon={<Star className="h-6 w-6 text-primary" />}
              delay={600}
            />
          </div>
        </div>
      </section>
      
      {/* Featured Workshops */}
      <section className="py-20 px-6 relative">
        {/* Section-specific overlay */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        
        <div className="container mx-auto relative z-10">
          <div className={cn(
            "flex flex-col md:flex-row md:items-end justify-between mb-12",
            isArabic ? "md:flex-row-reverse" : ""
          )}>
            <div>
              <div className="inline-block px-3 py-1 mb-4 text-xs font-medium text-primary bg-primary/10 rounded-full">
                {isArabic ? "شركاء موثوقون" : "Trusted Partners"}
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-2 text-white">
                {isArabic ? "ورش مميزة" : "Featured Workshops"}
              </h2>
              <p className="text-white/80 max-w-2xl">
                {isArabic ? "بعض من أعلى مراكز الصيانة تقييماً في الرياض." : "Some of the highest-rated maintenance centers in Riyadh."}
              </p>
            </div>
            <Link 
              to="/compare-workshops"
              className={cn(
                "inline-flex items-center text-white font-medium mt-4 md:mt-0 hover:text-white/80 transition-colors",
                isArabic ? "flex-row-reverse" : ""
              )}
            >
              {isArabic ? (
                <>
                  عرض جميع الورش
                  <ArrowRight className="mr-2 h-4 w-4 rotate-180" />
                </>
              ) : (
                <>
                  View all workshops
                  <ArrowRight className="ml-2 h-4 w-4" />
                </>
              )}
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredWorkshops.map((workshop, index) => (
              <div 
                key={workshop.id} 
                className="glass-card rounded-2xl overflow-hidden animate-fade-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={workshop.image} 
                    alt={workshop.name} 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold text-lg">{workshop.name}</h3>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
                      <span>{workshop.rating.toFixed(1)}</span>
                    </div>
                  </div>
                  <p className="text-muted-foreground text-sm mb-4">{workshop.specialty}</p>
                  <Link 
                    to={`/compare-workshops`} 
                    className={cn(
                      "inline-flex items-center text-sm text-primary font-medium hover:text-primary/80 transition-colors",
                      isArabic ? "flex-row-reverse" : ""
                    )}
                  >
                    {isArabic ? (
                      <>
                        عرض التفاصيل
                        <ArrowRight className="mr-2 h-4 w-4 rotate-180" />
                      </>
                    ) : (
                      <>
                        View details
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 px-6 relative">
        {/* Section-specific overlay */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-white/70"></div>
        </div>
        
        <div className="container mx-auto text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            {isArabic ? "هل أنت مستعد للعثور على الورشة المثالية لسيارتك؟" : "Ready to find the perfect workshop for your vehicle?"}
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
            {isArabic 
              ? "أضف تفاصيل سيارتك واتصل بأفضل خدمات الصيانة في الرياض."
              : "Add your vehicle details and get connected with the best maintenance services in Riyadh."
            }
          </p>
          <div className={cn(
            "flex flex-col sm:flex-row justify-center gap-4",
            isArabic ? "sm:flex-row-reverse" : ""
          )}>
            <Link 
              to="/add-vehicle"
              className="px-6 py-3 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 transition-colors"
            >
              {isArabic ? "إضافة تفاصيل السيارة" : "Add Vehicle Details"}
            </Link>
            <Link 
              to="/compare-workshops"
              className="px-6 py-3 bg-secondary text-foreground rounded-lg font-medium hover:bg-secondary/70 transition-colors"
            >
              {isArabic ? "تصفح الورش" : "Browse Workshops"}
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;