export const useTheme = () => {
  return { theme: "light", setTheme: (theme: string) => {} };
};