import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/supabase';

// Get environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Validate environment variables with more specific error messages
if (!supabaseUrl) {
  throw new Error('Missing VITE_SUPABASE_URL environment variable. Please connect to Supabase using the "Connect to Supabase" button.');
}

if (!supabaseAnonKey) {
  throw new Error('Missing VITE_SUPABASE_ANON_KEY environment variable. Please connect to Supabase using the "Connect to Supabase" button.');
}

// Create Supabase client with enhanced retry configuration
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  },
  global: {
    headers: {
      'Content-Type': 'application/json'
    },
    fetch: async (...args) => {
      try {
        const response = await fetch(...args);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response;
      } catch (err) {
        console.error('Supabase fetch error:', err);
        if (err instanceof TypeError && err.message === 'Failed to fetch') {
          throw new Error('Unable to connect to Supabase. Please verify your internet connection and Supabase credentials.');
        }
        throw err;
      }
    }
  }
});

// Sample workshop for demo
export const fallbackWorkshops = [
  {
    id: "11111111-1111-1111-1111-111111111111",
    name: "Al-Faisal Auto Center",
    rating: 4.8,
    review_count: 125,
    image: "https://images.unsplash.com/photo-1540066019607-e5f69323a8dc?q=80&w=1000&auto=format&fit=crop",
    location: "King Fahd Road, Riyadh",
    distance: "3.2 km",
    hours: "8:00 AM - 8:00 PM",
    phone: "+966 12 345 6789",
    services: ["Oil Change", "Brake Service", "Engine Repair", "A/C Service", "Electrical Systems", "Transmission"],
    specialties: ["Toyota", "Lexus", "Honda", "Premium Cars"]
  }
];

// Enhanced connection test with detailed error handling
export const testConnection = async () => {
  try {
    const { data, error } = await supabase.auth.getSession();
    if (error) {
      console.error('Supabase authentication error:', error);
      throw new Error(`Authentication error: ${error.message}`);
    }
    return { success: true };
  } catch (error) {
    console.error('Supabase connection test error:', error);
    if (error instanceof Error) {
      return { 
        success: false, 
        error: error.message 
      };
    }
    return { 
      success: false, 
      error: 'An unexpected error occurred while connecting to Supabase.' 
    };
  }
};