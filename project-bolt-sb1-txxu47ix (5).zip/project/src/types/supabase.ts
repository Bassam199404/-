export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      vehicles: {
        Row: {
          id: string
          created_at: string
          make: string
          model: string
          year: number
          mileage: number
          service_type: string
          description: string
          user_id: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          make: string
          model: string
          year: number
          mileage: number
          service_type: string
          description: string
          user_id?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          make?: string
          model?: string
          year?: number
          mileage?: number
          service_type?: string
          description?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "vehicles_user_id_fkey"
            columns: ["user_id"]
            referencedRelation: "users"
            referencedColumns: ["id"]
          }
        ]
      }
      workshops: {
        Row: {
          id: string
          created_at: string
          name: string
          rating: number
          review_count: number
          image: string
          location: string
          distance: string
          hours: string
          phone: string
        }
        Insert: {
          id?: string
          created_at?: string
          name: string
          rating: number
          review_count: number
          image: string
          location: string
          distance: string
          hours: string
          phone: string
        }
        Update: {
          id?: string
          created_at?: string
          name?: string
          rating?: number
          review_count?: number
          image?: string
          location?: string
          distance?: string
          hours?: string
          phone?: string
        }
        Relationships: []
      }
      workshop_services: {
        Row: {
          id: string
          workshop_id: string
          service: string
        }
        Insert: {
          id?: string
          workshop_id: string
          service: string
        }
        Update: {
          id?: string
          workshop_id?: string
          service?: string
        }
        Relationships: [
          {
            foreignKeyName: "workshop_services_workshop_id_fkey"
            columns: ["workshop_id"]
            referencedRelation: "workshops"
            referencedColumns: ["id"]
          }
        ]
      }
      workshop_specialties: {
        Row: {
          id: string
          workshop_id: string
          specialty: string
        }
        Insert: {
          id?: string
          workshop_id: string
          specialty: string
        }
        Update: {
          id?: string
          workshop_id?: string
          specialty?: string
        }
        Relationships: [
          {
            foreignKeyName: "workshop_specialties_workshop_id_fkey"
            columns: ["workshop_id"]
            referencedRelation: "workshops"
            referencedColumns: ["id"]
          }
        ]
      }
      vehicle_images: {
        Row: {
          id: string
          vehicle_id: string
          image_url: string
          created_at: string
        }
        Insert: {
          id?: string
          vehicle_id: string
          image_url: string
          created_at?: string
        }
        Update: {
          id?: string
          vehicle_id?: string
          image_url?: string
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_images_vehicle_id_fkey"
            columns: ["vehicle_id"]
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          }
        ]
      }
      price_estimates: {
        Row: {
          id: string
          vehicle_make: string
          service_type: string
          min_price: number
          max_price: number
        }
        Insert: {
          id?: string
          vehicle_make: string
          service_type: string
          min_price: number
          max_price: number
        }
        Update: {
          id?: string
          vehicle_make?: string
          service_type?: string
          min_price?: number
          max_price?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}