// Google Maps types
declare namespace google.maps {
  class Map {
    constructor(mapDiv: Element, opts?: MapOptions);
    setCenter(latLng: LatLng | LatLngLiteral): void;
    setZoom(zoom: number): void;
    getZoom(): number;
    fitBounds(bounds: LatLngBounds | LatLngBoundsLiteral): void;
  }
  
  interface MapOptions {
    center?: LatLng | LatLngLiteral;
    zoom?: number;
    mapTypeControl?: boolean;
    streetViewControl?: boolean;
    fullscreenControl?: boolean;
    zoomControl?: boolean;
    language?: string;
  }
  
  class LatLng {
    constructor(lat: number, lng: number);
    lat(): number;
    lng(): number;
  }
  
  interface LatLngLiteral {
    lat: number;
    lng: number;
  }
  
  class LatLngBounds {
    constructor();
    extend(latLng: LatLng | LatLngLiteral): LatLngBounds;
  }
  
  interface LatLngBoundsLiteral {
    east: number;
    north: number;
    south: number;
    west: number;
  }
  
  class Marker {
    constructor(opts?: MarkerOptions);
    setMap(map: Map | null): void;
    getPosition(): LatLng;
    setPosition(latLng: LatLng | LatLngLiteral): void;
    addListener(eventName: string, handler: Function): MapsEventListener;
  }
  
  interface MarkerOptions {
    position: LatLng | LatLngLiteral;
    map?: Map;
    title?: string;
    icon?: string | Icon | Symbol;
    animation?: Animation;
  }
  
  interface Icon {
    url?: string;
    path?: SymbolPath | string;
    scale?: number;
    fillColor?: string;
    fillOpacity?: number;
    strokeColor?: string;
    strokeWeight?: number;
  }
  
  interface Symbol {
    path: SymbolPath | string;
    scale?: number;
    fillColor?: string;
    fillOpacity?: number;
    strokeColor?: string;
    strokeWeight?: number;
  }
  
  enum SymbolPath {
    CIRCLE,
    FORWARD_CLOSED_ARROW,
    FORWARD_OPEN_ARROW,
    BACKWARD_CLOSED_ARROW,
    BACKWARD_OPEN_ARROW
  }
  
  enum Animation {
    BOUNCE,
    DROP
  }
  
  class InfoWindow {
    constructor(opts?: InfoWindowOptions);
    open(map?: Map, anchor?: Marker): void;
    close(): void;
    setContent(content: string | Element): void;
  }
  
  interface InfoWindowOptions {
    content?: string | Element;
    position?: LatLng | LatLngLiteral;
  }
  
  class Geocoder {
    constructor();
    geocode(request: GeocoderRequest, callback: (results: GeocoderResult[], status: GeocoderStatus) => void): void;
  }
  
  interface GeocoderRequest {
    address?: string;
    location?: LatLng | LatLngLiteral;
    bounds?: LatLngBounds | LatLngBoundsLiteral;
    componentRestrictions?: GeocoderComponentRestrictions;
    region?: string;
  }
  
  interface GeocoderComponentRestrictions {
    country: string | string[];
  }
  
  interface GeocoderResult {
    address_components: GeocoderAddressComponent[];
    formatted_address: string;
    geometry: {
      location: LatLng;
      location_type: GeocoderLocationType;
      viewport: LatLngBounds;
      bounds?: LatLngBounds;
    };
    place_id: string;
    types: string[];
  }
  
  interface GeocoderAddressComponent {
    long_name: string;
    short_name: string;
    types: string[];
  }
  
  enum GeocoderLocationType {
    APPROXIMATE,
    GEOMETRIC_CENTER,
    RANGE_INTERPOLATED,
    ROOFTOP
  }
  
  type GeocoderStatus = 'OK' | 'ZERO_RESULTS' | 'OVER_QUERY_LIMIT' | 'REQUEST_DENIED' | 'INVALID_REQUEST' | 'UNKNOWN_ERROR';
  
  class DistanceMatrixService {
    constructor();
    getDistanceMatrix(request: DistanceMatrixRequest, callback: (response: DistanceMatrixResponse, status: DistanceMatrixStatus) => void): void;
  }
  
  interface DistanceMatrixRequest {
    origins: (LatLng | LatLngLiteral | string)[];
    destinations: (LatLng | LatLngLiteral | string)[];
    travelMode: TravelMode;
    unitSystem?: UnitSystem;
    avoidHighways?: boolean;
    avoidTolls?: boolean;
  }
  
  interface DistanceMatrixResponse {
    originAddresses: string[];
    destinationAddresses: string[];
    rows: DistanceMatrixResponseRow[];
  }
  
  interface DistanceMatrixResponseRow {
    elements: DistanceMatrixResponseElement[];
  }
  
  interface DistanceMatrixResponseElement {
    status: DistanceMatrixElementStatus;
    duration: Duration;
    distance: Distance;
  }
  
  interface Duration {
    value: number;
    text: string;
  }
  
  interface Distance {
    value: number;
    text: string;
  }
  
  enum TravelMode {
    DRIVING,
    WALKING,
    BICYCLING,
    TRANSIT
  }
  
  enum UnitSystem {
    METRIC,
    IMPERIAL
  }
  
  type DistanceMatrixStatus = 'OK' | 'INVALID_REQUEST' | 'OVER_QUERY_LIMIT' | 'REQUEST_DENIED' | 'UNKNOWN_ERROR' | 'MAX_ELEMENTS_EXCEEDED' | 'MAX_DIMENSIONS_EXCEEDED';
  type DistanceMatrixElementStatus = 'OK' | 'NOT_FOUND' | 'ZERO_RESULTS';
  
  interface MapsEventListener {
    remove(): void;
  }
  
  const event: {
    addListener(instance: Object, eventName: string, handler: Function): MapsEventListener;
    removeListener(listener: MapsEventListener): void;
    clearListeners(instance: Object, eventName: string): void;
  };
  
  namespace places {
    class PlacesService {
      constructor(attrContainer: HTMLDivElement | Map);
      nearbySearch(request: PlaceSearchRequest, callback: (results: PlaceResult[] | null, status: PlacesServiceStatus) => void): void;
      getDetails(request: PlaceDetailsRequest, callback: (result: PlaceResult | null, status: PlacesServiceStatus) => void): void;
    }
    
    interface PlaceSearchRequest {
      location: LatLng | LatLngLiteral;
      radius?: number;
      bounds?: LatLngBounds | LatLngBoundsLiteral;
      keyword?: string;
      type?: string;
    }
    
    interface PlaceDetailsRequest {
      placeId: string;
      fields?: string[];
    }
    
    interface PlaceResult {
      place_id: string;
      name: string;
      formatted_address?: string;
      geometry: {
        location: LatLng;
        viewport?: LatLngBounds;
      };
      types?: string[];
      rating?: number;
      user_ratings_total?: number;
      vicinity?: string;
      photos?: PlacePhoto[];
    }
    
    interface PlacePhoto {
      getUrl(opts: PhotoOptions): string;
      height: number;
      width: number;
      html_attributions: string[];
    }
    
    interface PhotoOptions {
      maxWidth?: number;
      maxHeight?: number;
    }
    
    enum PlacesServiceStatus {
      OK,
      ZERO_RESULTS,
      OVER_QUERY_LIMIT,
      REQUEST_DENIED,
      INVALID_REQUEST,
      UNKNOWN_ERROR
    }
  }
}

// Extend Window interface
interface Window {
  google: {
    maps: typeof google.maps;
  };
}