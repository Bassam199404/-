import React from 'react';
import { X, Star, Check, Minus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { cn } from '../lib/utils';
import { useLanguage } from '../contexts/LanguageContext';
import { Workshop } from '../services/workshopService';

interface ComparisonModalProps {
  open: boolean;
  onClose: () => void;
  workshops: Workshop[];
}

const ComparisonModal: React.FC<ComparisonModalProps> = ({ open, onClose, workshops }) => {
  const { isArabic, dir, fontFamily } = useLanguage();
  
  // All unique services from all workshops
  const allServices = React.useMemo(() => {
    const servicesSet = new Set<string>();
    workshops.forEach(workshop => {
      workshop.services.forEach(service => servicesSet.add(service));
    });
    return Array.from(servicesSet).sort();
  }, [workshops]);
  
  // Check if a workshop offers a specific service
  const hasService = (workshop: Workshop, service: string) => {
    return workshop.services.includes(service);
  };
  
  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent 
        className="max-w-4xl w-[90vw] max-h-[90vh] overflow-y-auto"
        dir={dir}
        style={{ fontFamily }}
      >
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {isArabic ? "مقارنة الورش" : "Workshop Comparison"}
          </DialogTitle>
        </DialogHeader>
        
        <div className="mt-4">
          {/* Workshop Headers */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="col-span-1">
              {/* Empty cell for labels */}
            </div>
            {workshops.map(workshop => (
              <div key={workshop.id} className="col-span-1">
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto rounded-full overflow-hidden mb-2 border-2 border-primary">
                    <img 
                      src={workshop.image} 
                      alt={workshop.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="font-semibold text-sm mb-1">{workshop.name}</h3>
                  <div className="flex items-center justify-center">
                    <Star className="h-3 w-3 text-yellow-500 fill-yellow-500 mr-1" />
                    <span className="text-xs">{workshop.rating.toFixed(1)}</span>
                    <span className="text-xs text-gray-500 ml-1">({workshop.review_count})</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Basic Info Section */}
          <div className="mb-6">
            <h4 className="font-semibold mb-3 pb-2 border-b">
              {isArabic ? "معلومات أساسية" : "Basic Information"}
            </h4>
            
            {/* Location Row */}
            <div className="grid grid-cols-4 gap-4 mb-3 py-2">
              <div className="col-span-1 font-medium text-sm flex items-center">
                {isArabic ? "الموقع" : "Location"}
              </div>
              {workshops.map(workshop => (
                <div key={`${workshop.id}-location`} className="col-span-1 text-sm">
                  {workshop.location}
                  <div className="text-xs text-gray-500">{workshop.distance}</div>
                </div>
              ))}
            </div>
            
            {/* Hours Row */}
            <div className="grid grid-cols-4 gap-4 mb-3 py-2 bg-gray-50 rounded-md">
              <div className="col-span-1 font-medium text-sm flex items-center px-2">
                {isArabic ? "ساعات العمل" : "Working Hours"}
              </div>
              {workshops.map(workshop => (
                <div key={`${workshop.id}-hours`} className="col-span-1 text-sm px-2">
                  {workshop.hours}
                </div>
              ))}
            </div>
            
            {/* Phone Row */}
            <div className="grid grid-cols-4 gap-4 mb-3 py-2">
              <div className="col-span-1 font-medium text-sm flex items-center">
                {isArabic ? "رقم الهاتف" : "Phone"}
              </div>
              {workshops.map(workshop => (
                <div key={`${workshop.id}-phone`} className="col-span-1 text-sm">
                  {workshop.phone}
                </div>
              ))}
            </div>
            
            {/* Specialties Row */}
            <div className="grid grid-cols-4 gap-4 mb-3 py-2 bg-gray-50 rounded-md">
              <div className="col-span-1 font-medium text-sm flex items-center px-2">
                {isArabic ? "التخصصات" : "Specialties"}
              </div>
              {workshops.map(workshop => (
                <div key={`${workshop.id}-specialties`} className="col-span-1 text-sm px-2">
                  <div className="flex flex-wrap gap-1">
                    {workshop.specialties.map((specialty, index) => (
                      <span 
                        key={index} 
                        className="text-xs bg-secondary/50 text-gray-700 px-2 py-0.5 rounded-full"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Services Section */}
          <div>
            <h4 className="font-semibold mb-3 pb-2 border-b">
              {isArabic ? "الخدمات" : "Services"}
            </h4>
            
            {allServices.map((service, index) => (
              <div 
                key={service} 
                className={cn(
                  "grid grid-cols-4 gap-4 py-2",
                  index % 2 === 0 ? "bg-gray-50 rounded-md" : ""
                )}
              >
                <div className="col-span-1 text-sm flex items-center px-2">
                  {service}
                </div>
                {workshops.map(workshop => (
                  <div 
                    key={`${workshop.id}-${service}`} 
                    className="col-span-1 text-sm flex justify-center px-2"
                  >
                    {hasService(workshop, service) ? (
                      <Check className="h-5 w-5 text-green-500" />
                    ) : (
                      <Minus className="h-5 w-5 text-gray-300" />
                    )}
                  </div>
                ))}
              </div>
            ))}
          </div>
          
          {/* Action Buttons */}
          <div className="mt-8 grid grid-cols-4 gap-4">
            <div className="col-span-1">
              {/* Empty cell */}
            </div>
            {workshops.map(workshop => (
              <div key={`${workshop.id}-actions`} className="col-span-1">
                <button
                  type="button"
                  className="w-full py-2 px-3 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors"
                >
                  {isArabic ? "طلب عرض سعر" : "Request Quote"}
                </button>
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ComparisonModal;