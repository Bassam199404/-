import React, { useState, useEffect, useRef } from 'react';
import { Search, X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { cn } from '../lib/utils';

interface SearchInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  autoFocus?: boolean;
}

const SearchInput: React.FC<SearchInputProps> = ({
  value,
  onChange,
  placeholder,
  className,
  autoFocus = false
}) => {
  const { isArabic } = useLanguage();
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    if (autoFocus && inputRef.current) {
      inputRef.current.focus();
    }
  }, [autoFocus]);
  
  const handleClear = () => {
    onChange('');
    inputRef.current?.focus();
  };
  
  return (
    <div className={cn(
      "relative flex items-center transition-all",
      isFocused && "ring-2 ring-primary/20 rounded-lg",
      className
    )}>
      <Search className={cn(
        "absolute h-4 w-4 text-muted-foreground transition-colors",
        isArabic ? "right-3" : "left-3",
        isFocused && "text-primary"
      )} />
      
      <input
        ref={inputRef}
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        placeholder={placeholder}
        className={cn(
          "w-full bg-background rounded-lg border border-input",
          "focus:outline-none focus:ring-0 focus:border-primary/30",
          "transition-all placeholder:text-muted-foreground/70",
          isArabic ? "pr-10 pl-4" : "pl-10 pr-4",
          "py-2.5 text-sm"
        )}
      />
      
      {value && (
        <button
          type="button"
          onClick={handleClear}
          className={cn(
            "absolute p-1 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors",
            isArabic ? "left-3" : "right-3"
          )}
          aria-label={isArabic ? "مسح البحث" : "Clear search"}
        >
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  );
};

export default SearchInput;