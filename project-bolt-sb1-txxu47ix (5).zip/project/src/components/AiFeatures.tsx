import React from "react";
import { Bot, Sparkles, Zap, BrainCircuit, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";
import { cn } from "../lib/utils";

const AiFeatures = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  
  const features = [
    {
      icon: <Bot className="h-8 w-8 text-primary" />,
      title: isArabic ? "مساعد ذكي" : "AI Assistant",
      description: isArabic 
        ? "احصل على إجابات فورية لأسئلتك حول صيانة السيارات والورش"
        : "Get instant answers to your questions about car maintenance and workshops",
      link: "/ai-assistant"
    },
    {
      icon: <Sparkles className="h-8 w-8 text-primary" />,
      title: isArabic ? "توصيات مخصصة" : "Personalized Recommendations",
      description: isArabic 
        ? "احصل على توصيات مخصصة للورش بناءً على نوع سيارتك واحتياجاتك"
        : "Get personalized workshop recommendations based on your vehicle type and needs",
      link: "/add-vehicle"
    },
    {
      icon: <Zap className="h-8 w-8 text-primary" />,
      title: isArabic ? "تشخيص المشاكل" : "Problem Diagnosis",
      description: isArabic 
        ? "وصف أعراض مشكلة سيارتك واحصل على تشخيص أولي وخطوات العمل الموصى بها"
        : "Describe your car problem symptoms and get a preliminary diagnosis and recommended actions",
      link: "/ai-assistant"
    },
    {
      icon: <BrainCircuit className="h-8 w-8 text-primary" />,
      title: isArabic ? "جدولة الصيانة الذكية" : "Smart Maintenance Scheduling",
      description: isArabic 
        ? "الحصول على تذكيرات وجداول صيانة مخصصة بناءً على نوع سيارتك وأنماط القيادة"
        : "Get customized maintenance reminders and schedules based on your vehicle type and driving patterns",
      link: "/add-vehicle"
    }
  ];
  
  return (
    <section 
      className="py-16 px-6 bg-gray-50"
      dir={dir}
      style={{ fontFamily }}
    >
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-2 bg-primary/10 rounded-full mb-4">
            <Bot className="h-6 w-6 text-primary" />
          </div>
          <h2 className="text-3xl font-bold mb-4">
            {isArabic ? "أداء الذكاء الاصطناعي" : "AI Performance"}
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {isArabic 
              ? "استفد من قوة الذكاء الاصطناعي للحصول على تجربة صيانة سيارات أكثر ذكاءً وكفاءة"
              : "Leverage the power of artificial intelligence for a smarter, more efficient car maintenance experience"
            }
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="glass-card rounded-xl p-6 hover:shadow-md transition-shadow"
            >
              <div className="p-3 bg-primary/10 rounded-xl w-fit mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-gray-600 mb-4">{feature.description}</p>
              <Link 
                to={feature.link}
                className={cn(
                  "inline-flex items-center text-primary font-medium hover:text-primary/80 transition-colors",
                  isArabic ? "flex-row-reverse" : ""
                )}
              >
                {isArabic ? (
                  <>
                    استكشاف
                    <ArrowRight className="mr-1 h-4 w-4 rotate-180" />
                  </>
                ) : (
                  <>
                    Explore
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </>
                )}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AiFeatures;