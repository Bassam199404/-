import React, { useState } from "react";
import { cn } from "../lib/utils";
import { ChevronRight } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  delay?: number;
}

const ServiceCard = ({ title, description, icon, delay = 0 }: ServiceCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  const { isArabic } = useLanguage();
  
  return (
    <div 
      className={cn(
        "glass-card rounded-2xl p-6 transition-all duration-300 group animate-fade-up backdrop-blur-md bg-white/90",
        isHovered ? "transform -translate-y-1 shadow-md" : ""
      )}
      style={{ animationDelay: `${delay}ms` }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex flex-col h-full">
        <div className="p-3 bg-primary/10 rounded-xl w-fit mb-5">
          {icon}
        </div>
        
        <h3 className="text-xl font-semibold mb-3">{title}</h3>
        
        <p className="text-muted-foreground mb-4 flex-grow">
          {description}
        </p>
        
        <div className={cn(
          "flex items-center text-primary text-sm font-medium transition-all duration-300",
          isHovered ? (isArabic ? "-translate-x-1" : "translate-x-1") : "",
          isArabic ? "flex-row-reverse" : ""
        )}>
          {isArabic ? (
            <>
              <ChevronRight className="ml-1 h-4 w-4 rotate-180" />
              عرض المزيد
            </>
          ) : (
            <>
              Learn More
              <ChevronRight className="ml-1 h-4 w-4" />
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;