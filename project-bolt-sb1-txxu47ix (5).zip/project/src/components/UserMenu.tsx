import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';

const UserMenu = () => {
  const { isArabic } = useLanguage();
  
  return null; // Remove user menu completely
};

export default UserMenu;