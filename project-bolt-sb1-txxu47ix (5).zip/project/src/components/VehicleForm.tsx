import React, { useState, useRef } from "react";
import { cn } from "../lib/utils";
import { Upload, X, Camera, Check, ArrowRight, Star } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { useNavigate } from "react-router-dom";
import { submitVehicleInfo, getWorkshopEstimates, VehicleFormData } from "../services/vehicleService";
import { toast } from "sonner";

const VehicleForm = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const navigate = useNavigate();
  const [images, setImages] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formComplete, setFormComplete] = useState(false);
  const [showPricing, setShowPricing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [workshopEstimates, setWorkshopEstimates] = useState<any[]>([]);
  
  // Form state
  const [make, setMake] = useState("");
  const [model, setModel] = useState("");
  const [year, setYear] = useState("");
  const [mileage, setMileage] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [description, setDescription] = useState("");
  
  // Handle file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArray = Array.from(e.target.files);
      const newImages = filesArray.map(file => URL.createObjectURL(file));
      setImages(prev => [...prev, ...newImages]);
    }
  };
  
  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Prepare vehicle data
      const vehicleData: VehicleFormData = {
        make,
        model,
        year: parseInt(year),
        mileage: parseInt(mileage),
        service_type: serviceType,
        description
      };
      
      // Submit to Supabase
      const result = await submitVehicleInfo(vehicleData, images);
      
      if (result.success) {
        // Get workshop estimates
        const estimates = await getWorkshopEstimates(make, serviceType);
        setWorkshopEstimates(estimates);
        
        setFormComplete(true);
        setShowPricing(true);
      } else {
        toast.error(isArabic ? "حدث خطأ أثناء حفظ البيانات" : "Error saving data");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      toast.error(isArabic ? "حدث خطأ غير متوقع" : "An unexpected error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Remove an image
  const removeImage = (index: number) => {
    const newImages = [...images];
    URL.revokeObjectURL(newImages[index]);
    newImages.splice(index, 1);
    setImages(newImages);
  };
  
  // Trigger file input click
  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };
  
  // Navigate to compare workshops
  const goToCompareWorkshops = () => {
    navigate('/compare-workshops');
  };
  
  return (
    <div 
      className="glass-card rounded-2xl p-8 shadow-sm max-w-3xl mx-auto animate-fade-up"
      dir={dir}
      style={{ fontFamily }}
    >
      {!showPricing ? (
        <>
          <h2 className="text-2xl font-bold mb-6">
            {isArabic ? "معلومات المركبة" : "Vehicle Information"}
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  {isArabic ? "الشركة المصنعة" : "Make"}
                </label>
                <select 
                  className="w-full px-4 py-3 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                  value={make}
                  onChange={(e) => setMake(e.target.value)}
                  required
                >
                  <option value="" disabled>{isArabic ? "اختر الشركة المصنعة" : "Select vehicle make"}</option>
                  <option value="toyota">Toyota</option>
                  <option value="honda">Honda</option>
                  <option value="nissan">Nissan</option>
                  <option value="ford">Ford</option>
                  <option value="chevrolet">Chevrolet</option>
                  <option value="bmw">BMW</option>
                  <option value="mercedes">Mercedes</option>
                  <option value="audi">Audi</option>
                  <option value="kia">Kia</option>
                  <option value="hyundai">Hyundai</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  {isArabic ? "الموديل" : "Model"}
                </label>
                <input 
                  type="text" 
                  placeholder={isArabic ? "مثال: كامري، أكورد، التيما" : "e.g. Camry, Accord, Altima"}
                  className="w-full px-4 py-3 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  {isArabic ? "السنة" : "Year"}
                </label>
                <select 
                  className="w-full px-4 py-3 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                  required
                >
                  <option value="" disabled>{isArabic ? "اختر السنة" : "Select year"}</option>
                  {Array.from({ length: 30 }, (_, i) => 2023 - i).map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  {isArabic ? "المسافة المقطوعة (كم)" : "Mileage (km)"}
                </label>
                <input 
                  type="number" 
                  placeholder={isArabic ? "مثال: 85000" : "e.g. 85000"}
                  className="w-full px-4 py-3 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                  value={mileage}
                  onChange={(e) => setMileage(e.target.value)}
                  required
                />
              </div>
            </div>
            
            {/* Service Type */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                {isArabic ? "نوع الخدمة" : "Service Type"}
              </label>
              <select 
                className="w-full px-4 py-3 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                value={serviceType}
                onChange={(e) => setServiceType(e.target.value)}
                required
              >
                <option value="" disabled>{isArabic ? "اختر نوع الخدمة" : "Select service type"}</option>
                <option value="regular">{isArabic ? "صيانة دورية" : "Regular Maintenance"}</option>
                <option value="repair">{isArabic ? "إصلاح" : "Repair"}</option>
                <option value="accident">{isArabic ? "أضرار حادث" : "Accident Damage"}</option>
                <option value="diagnostic">{isArabic ? "فحص تشخيصي" : "Diagnostic Check"}</option>
                <option value="parts">{isArabic ? "استبدال قطع غيار" : "Parts Replacement"}</option>
              </select>
            </div>
            
            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                {isArabic ? "وصف المشكلة" : "Description of Issue"}
              </label>
              <textarea 
                rows={4} 
                placeholder={isArabic ? "صف المشكلة في سيارتك" : "Describe the issue with your vehicle"}
                className="w-full px-4 py-3 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all resize-none"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              ></textarea>
            </div>
            
            {/* Image Upload */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                {isArabic ? "تحميل الصور" : "Upload Images"}
              </label>
              
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                multiple
                className="hidden"
              />
              
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-4">
                {/* Images preview */}
                {images.map((image, index) => (
                  <div key={index} className="relative rounded-lg overflow-hidden aspect-square">
                    <img 
                      src={image} 
                      alt={isArabic ? `ضرر المركبة ${index + 1}` : `Vehicle damage ${index + 1}`} 
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute top-1 right-1 bg-foreground/80 text-white p-1 rounded-full"
                      aria-label={isArabic ? "إزالة الصورة" : "Remove image"}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
                
                {/* Upload button */}
                {images.length < 8 && (
                  <button
                    type="button"
                    onClick={triggerFileInput}
                    className="border-2 border-dashed border-input rounded-lg flex flex-col items-center justify-center p-4 hover:border-primary/50 transition-all aspect-square"
                  >
                    <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                    <span className="text-xs text-muted-foreground text-center">
                      {isArabic ? "انقر للتحميل" : "Click to upload"}
                    </span>
                  </button>
                )}
              </div>
              
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={triggerFileInput}
                  className="inline-flex items-center text-sm text-primary font-medium"
                >
                  <Camera className="h-4 w-4 mr-1" />
                  {isArabic ? "تحميل الصور" : "Upload photos"}
                </button>
                <span className="text-xs text-muted-foreground">
                  {isArabic 
                    ? "(بحد أقصى 8 صور، توضح تفاصيل الضرر)" 
                    : "(max 8 images, showing damage details)"
                  }
                </span>
              </div>
            </div>
            
            {/* Submit Button */}
            <div>
              <button
                type="submit"
                disabled={isSubmitting || formComplete}
                className={cn(
                  "w-full py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center",
                  formComplete 
                    ? "bg-green-500 text-white" 
                    : isSubmitting 
                      ? "bg-primary/70 text-white/80 cursor-wait" 
                      : "bg-primary text-white hover:bg-primary/90"
                )}
                style={{ opacity: 1 }} // Ensure button is visible
              >
                {formComplete ? (
                  <>
                    <Check className="mr-2 h-5 w-5" />
                    {isArabic ? "تم إرسال المعلومات" : "Information Submitted"}
                  </>
                ) : isSubmitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    {isArabic ? "جاري الإرسال..." : "Submitting..."}
                  </>
                ) : (
                  isArabic ? "إرسال معلومات المركبة" : "Submit Vehicle Information"
                )}
              </button>
            </div>
          </form>
        </>
      ) : (
        <>
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 text-green-500 rounded-full mb-4">
              <Check className="h-8 w-8" />
            </div>
            <h2 className="text-2xl font-bold mb-2">
              {isArabic ? "تم استلام معلومات المركبة" : "Vehicle Information Received"}
            </h2>
            <p className="text-muted-foreground">
              {isArabic 
                ? "بناءً على تفاصيل سيارتك، إليك تقديرات الأسعار من الورش المختلفة"
                : "Based on your vehicle details, here are price estimates from different workshops"
              }
            </p>
          </div>
          
          <div className="space-y-6 mb-8">
            <h3 className="text-lg font-semibold border-b pb-2">
              {isArabic ? "تقديرات الأسعار" : "Price Estimates"}
            </h3>
            
            {workshopEstimates.map((workshop, index) => (
              <div 
                key={workshop.id} 
                className="flex items-center justify-between p-4 rounded-lg bg-secondary/20 hover:bg-secondary/30 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-primary">
                    <img 
                      src={workshop.image} 
                      alt={workshop.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-medium">{workshop.name}</h4>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Star className="h-3 w-3 text-yellow-500 fill-yellow-500 mr-1" />
                      <span>{workshop.rating.toFixed(1)}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-primary">{workshop.price}</div>
                  <div className="text-xs text-muted-foreground">
                    {isArabic ? "تقدير السعر" : "Price estimate"}
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              type="button"
              onClick={goToCompareWorkshops}
              className="flex-1 py-3 px-4 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 transition-colors flex items-center justify-center"
            >
              {isArabic ? (
                <>
                  مقارنة الورش
                  <ArrowRight className="mr-2 h-5 w-5 rotate-180" />
                </>
              ) : (
                <>
                  Compare Workshops
                  <ArrowRight className="ml-2 h-5 w-5" />
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => setShowPricing(false)}
              className="flex-1 py-3 px-4 bg-secondary text-foreground rounded-lg font-medium hover:bg-secondary/70 transition-colors"
            >
              {isArabic ? "تعديل معلومات المركبة" : "Edit Vehicle Information"}
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default VehicleForm;