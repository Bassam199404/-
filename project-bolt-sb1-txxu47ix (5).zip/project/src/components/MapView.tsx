import React, { useState, useEffect, useRef } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { MapPin, Loader } from 'lucide-react';

interface MapViewProps {
  workshops?: any[];
  onWorkshopSelect?: (workshop: any) => void;
  height?: string;
  width?: string;
  className?: string;
}

const MapView: React.FC<MapViewProps> = ({
  workshops = [],
  onWorkshopSelect,
  height = '400px',
  width = '100%',
  className = ''
}) => {
  const { isArabic } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  return (
    <div className={`relative rounded-lg overflow-hidden ${className}`} style={{ height, width }}>
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100 bg-opacity-75 z-10">
          <div className="flex flex-col items-center">
            <Loader className="h-8 w-8 text-primary animate-spin mb-2" />
            <p className="text-sm text-gray-600">
              {isArabic ? 'جاري تحميل الخريطة...' : 'Loading map...'}
            </p>
          </div>
        </div>
      )}
      
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100 z-10">
          <div className="flex flex-col items-center text-center p-4">
            <MapPin className="h-8 w-8 text-red-500 mb-2" />
            <p className="text-sm text-gray-700 mb-1">{error}</p>
            <p className="text-xs text-gray-500">
              {isArabic 
                ? 'يرجى التحقق من اتصالك بالإنترنت والسماح بالوصول إلى الموقع'
                : 'Please check your internet connection and allow location access'
              }
            </p>
          </div>
        </div>
      )}
      
      <iframe 
        src="https://maps.google.com/maps?q=car+repair+Riyadh&z=13&output=embed"
        width="100%" 
        height="100%" 
        style={{ border: 0 }} 
        allowFullScreen 
        loading="lazy" 
        referrerPolicy="no-referrer-when-downgrade"
      ></iframe>
    </div>
  );
};

export default MapView;