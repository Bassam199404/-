import React from 'react';
import { Globe } from 'lucide-react';
import { cn } from '../lib/utils';
import { useLanguage } from '../contexts/LanguageContext';

interface LanguageToggleProps {
  className?: string;
}

const LanguageToggle: React.FC<LanguageToggleProps> = ({ className }) => {
  const { isArabic, setIsArabic } = useLanguage();
  
  return (
    <div className={cn("flex items-center", className)}>
      <button 
        onClick={() => setIsArabic(!isArabic)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 transition-colors"
        aria-label={isArabic ? "Switch to English" : "التبديل إلى العربية"}
      >
        <Globe className="h-5 w-5 text-slate-600" />
        <span className={cn(
          "text-sm font-medium",
          isArabic && "font-['Noto_Sans_Arabic']"
        )}>
          {isArabic ? "English" : "العربية"}
        </span>
      </button>
    </div>
  );
};

export default LanguageToggle;