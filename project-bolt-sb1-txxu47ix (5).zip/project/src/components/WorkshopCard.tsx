import React, { useState } from 'react';
import { Star, MapPin, Clock, Phone, Check } from 'lucide-react';
import { cn } from '../lib/utils';
import { useLanguage } from '../contexts/LanguageContext';

interface WorkshopCardProps {
  id: string;
  name: string;
  rating: number;
  reviewCount: number;
  image: string;
  location: string;
  distance: string;
  hours: string;
  phone: string;
  services: string[];
  specialties: string[];
  isSelected: boolean;
  onSelect: () => void;
}

const WorkshopCard: React.FC<WorkshopCardProps> = ({
  id,
  name,
  rating,
  reviewCount,
  image,
  location,
  distance,
  hours,
  phone,
  services,
  specialties,
  isSelected,
  onSelect
}) => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const [expanded, setExpanded] = useState(false);
  const [imageError, setImageError] = useState(false);
  
  // Fallback image if the main image fails to load
  const fallbackImage = "https://alskeb.com/wp-content/uploads/2020/01/eb00f2f59a52ac99e116f8e399283a54.jpg";
  
  return (
    <div 
      className={cn(
        "glass-card rounded-xl overflow-hidden transition-all duration-300 animate-fade-up",
        isSelected ? "ring-2 ring-primary" : "hover:shadow-md"
      )}
      dir={dir}
      style={{ fontFamily }}
    >
      {/* Workshop Image Container */}
      <div className="relative w-full h-48 bg-gray-100">
        <img 
          src={imageError ? fallbackImage : image}
          alt={name}
          className="absolute inset-0 w-full h-full object-cover"
          onError={() => setImageError(true)}
          loading="lazy"
        />
        
        {/* Gradient Overlay */}
        <div 
          className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"
          aria-hidden="true"
        />
        
        {/* Selection Button */}
        <button
          type="button"
          onClick={onSelect}
          className={cn(
            "absolute top-3 right-3 p-2 rounded-full transition-colors z-10",
            isSelected 
              ? "bg-primary text-white" 
              : "bg-white/80 text-gray-700 hover:bg-white"
          )}
          aria-label={isSelected ? "Deselect workshop" : "Select workshop for comparison"}
        >
          {isSelected ? <Check className="h-5 w-5" /> : <span className="text-xs font-medium px-1">+</span>}
        </button>
        
        {/* Rating Badge */}
        <div className="absolute bottom-3 left-3 bg-white/90 text-primary px-2 py-1 rounded-md text-sm font-medium flex items-center z-10">
          <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
          <span>{rating.toFixed(1)}</span>
          <span className="text-xs text-gray-500 ml-1">({reviewCount})</span>
        </div>
      </div>
      
      {/* Workshop Info */}
      <div className="p-5">
        <h3 className="font-bold text-lg mb-2">{name}</h3>
        
        <div className="space-y-2 mb-4">
          <div className="flex items-start">
            <MapPin className="h-4 w-4 text-gray-500 mt-1 mr-2 flex-shrink-0" />
            <div>
              <p className="text-sm text-gray-700">{location}</p>
              <p className="text-xs text-gray-500">{distance}</p>
            </div>
          </div>
          
          <div className="flex items-center">
            <Clock className="h-4 w-4 text-gray-500 mr-2 flex-shrink-0" />
            <p className="text-sm text-gray-700">{hours}</p>
          </div>
          
          <div className="flex items-center">
            <Phone className="h-4 w-4 text-gray-500 mr-2 flex-shrink-0" />
            <p className="text-sm text-gray-700">{phone}</p>
          </div>
        </div>
        
        {/* Specialties */}
        <div className="mb-4">
          <h4 className="text-sm font-medium mb-2">
            {isArabic ? "التخصصات" : "Specialties"}
          </h4>
          <div className="flex flex-wrap gap-2">
            {specialties.slice(0, 3).map((specialty, index) => (
              <span 
                key={index} 
                className="text-xs bg-secondary/50 text-gray-700 px-2 py-1 rounded-full"
              >
                {specialty}
              </span>
            ))}
            {specialties.length > 3 && (
              <span className="text-xs text-gray-500">
                +{specialties.length - 3} more
              </span>
            )}
          </div>
        </div>
        
        {/* Services */}
        <div>
          <h4 className="text-sm font-medium mb-2">
            {isArabic ? "الخدمات" : "Services"}
          </h4>
          <div className="flex flex-wrap gap-2">
            {services.slice(0, expanded ? services.length : 4).map((service, index) => (
              <span 
                key={index} 
                className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full"
              >
                {service}
              </span>
            ))}
            {!expanded && services.length > 4 && (
              <button
                type="button"
                onClick={() => setExpanded(true)}
                className="text-xs text-primary hover:underline"
              >
                +{services.length - 4} more
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkshopCard;