import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Wrench, ShieldCheck, Clock } from "lucide-react";
import { cn } from "../lib/utils";
import { useLanguage } from "../contexts/LanguageContext";

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);
  const { isArabic, dir, fontFamily } = useLanguage();

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section 
      className="relative min-h-[calc(100vh-4rem)] flex items-center overflow-hidden py-16 lg:py-24 px-4 sm:px-6"
      dir={dir}
      style={{ fontFamily }}
    >
      {/* Decorative elements */}
      <div className="absolute top-1/4 right-10 w-48 h-48 lg:w-64 lg:h-64 bg-primary/30 rounded-full blur-3xl z-10 animate-pulse" style={{animationDuration: '8s'}}></div>
      <div className="absolute bottom-1/4 left-10 w-32 h-32 lg:w-48 lg:h-48 bg-blue-400/20 rounded-full blur-3xl z-10 animate-pulse" style={{animationDuration: '6s'}}></div>
      
      <div className="container relative mx-auto max-w-7xl z-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Left column: text content */}
          <div className={cn(
            "space-y-6 transition-all duration-700 transform",
            isVisible 
              ? "opacity-100 translate-x-0" 
              : "opacity-0 -translate-x-12"
          )}>
            <div>
              <div className="inline-block px-3 py-1 mb-4 sm:mb-6 text-xs font-medium text-white bg-white/20 backdrop-blur-sm rounded-full">
                {isArabic ? "صيانة السيارات بطريقة بسيطة" : "Car maintenance made simple"}
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold tracking-tight text-white leading-tight drop-shadow-md">
                {isArabic ? "صيانة سمارت - ابحث عن ورش موثوقة في الرياض" : "Maintenance Smart - Find trusted workshops in Riyadh"}
              </h1>
              <p className="mt-4 sm:mt-6 text-lg sm:text-xl text-white/90 max-w-2xl drop-shadow">
                {isArabic 
                  ? "تواصل مع ورش صيانة موثوقة ومتاجر قطع غيار لاحتياجات سيارتك"
                  : "Connect with reliable maintenance workshops and spare parts stores for your vehicle needs"
                }
              </p>
            </div>
            
            <div className={cn(
              "flex flex-col sm:flex-row gap-3 sm:gap-4 pt-2",
              isArabic ? "sm:flex-row-reverse" : ""
            )}>
              <Link 
                to="/add-vehicle"
                className="inline-flex items-center justify-center px-6 py-3 text-base font-medium text-primary bg-white rounded-lg shadow-lg hover:bg-gray-100 transition-colors"
              >
                {isArabic ? (
                  <>
                    ابدأ الآن
                    <ArrowRight className="mr-2 h-5 w-5 rotate-180" />
                  </>
                ) : (
                  <>
                    Get Started
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </>
                )}
              </Link>
              <Link 
                to="/compare-workshops"
                className="inline-flex items-center justify-center px-6 py-3 text-base font-medium text-white border-2 border-white/70 bg-white/10 backdrop-blur-sm rounded-lg hover:bg-white/20 transition-colors"
              >
                {isArabic ? "مقارنة الورش" : "Compare Workshops"}
              </Link>
            </div>
          </div>
          
          {/* Right column: features */}
          <div className={cn(
            "grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 transition-all duration-700 delay-200",
            isVisible 
              ? "opacity-100 translate-x-0" 
              : "opacity-0 translate-x-12"
          )}>
            <FeatureCard 
              icon={<Wrench className="h-8 w-8 text-primary" />}
              title={isArabic ? "إصلاحات عالية الجودة" : "Quality Repairs"}
              description={isArabic 
                ? "تواصل مع ورش معتمدة متخصصة في طراز سيارتك"
                : "Connect with certified workshops specializing in your vehicle model"
              }
            />
            <FeatureCard 
              icon={<ShieldCheck className="h-8 w-8 text-primary" />}
              title={isArabic ? "خدمات موثوقة" : "Trusted Services"}
              description={isArabic 
                ? "ورش تم التحقق منها من خلال تقييمات المستخدمين الشفافة"
                : "Workshops vetted through transparent user reviews and ratings"
              }
            />
            <FeatureCard 
              icon={<Clock className="h-8 w-8 text-primary" />}
              title={isArabic ? "توفير الوقت" : "Time Saving"}
              description={isArabic 
                ? "ابحث وقارن الخدمات بسرعة دون مكالمات هاتفية لا نهاية لها"
                : "Quickly find and compare services without endless phone calls"
              }
            />
            <div className="glass-card p-6 rounded-2xl flex items-center justify-center h-full backdrop-blur-md bg-white/80">
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-primary">300+</div>
                <div className="text-sm text-muted-foreground mt-2">
                  {isArabic ? "ورشة موثوقة" : "Trusted Workshops"}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard = ({ icon, title, description }: FeatureCardProps) => (
  <div className="glass-card p-4 sm:p-6 rounded-2xl h-full backdrop-blur-md bg-white/80">
    <div className="mb-4">
      {icon}
    </div>
    <h3 className="text-lg font-semibold mb-2">{title}</h3>
    <p className="text-muted-foreground text-sm">{description}</p>
  </div>
);

export default Hero;