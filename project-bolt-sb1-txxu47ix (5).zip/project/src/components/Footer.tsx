import React from "react";
import { Link } from "react-router-dom";
import { Car } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { cn } from "../lib/utils";

const Footer = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  
  return (
    <footer 
      className="bg-black text-white py-12 px-4 sm:px-6"
      dir={dir}
      style={{ fontFamily }}
    >
      <div className="container mx-auto max-w-6xl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <Car className="h-6 w-6 text-blue-400" />
              <span className={cn("font-bold text-xl", isArabic && "font-['Noto_Sans_Arabic']")}>
                {isArabic ? "صيانة سمارت" : "Maintenance Smart"}
              </span>
            </div>
            <p className={cn(
              "text-white/70 mb-6",
              isArabic && "font-['Noto_Sans_Arabic']"
            )}>
              {isArabic 
                ? "شريكك الموثوق للعناية بالسيارات. نقدم خدمات صيانة وإصلاح عالية الجودة."
                : "Your trusted auto care partner. We provide high-quality maintenance and repair services."
              }
            </p>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-6">
              {isArabic ? "روابط سريعة" : "Quick Links"}
            </h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-white/70 hover:text-white transition-colors">
                  {isArabic ? "الرئيسية" : "Home"}
                </Link>
              </li>
              <li>
                <Link to="/add-vehicle" className="text-white/70 hover:text-white transition-colors">
                  {isArabic ? "إضافة مركبة" : "Add Vehicle"}
                </Link>
              </li>
              <li>
                <Link to="/compare-workshops" className="text-white/70 hover:text-white transition-colors">
                  {isArabic ? "مقارنة الورش" : "Compare Workshops"}
                </Link>
              </li>
              <li>
                <Link to="/ai-assistant" className="text-white/70 hover:text-white transition-colors">
                  {isArabic ? "المساعد الذكي" : "AI Assistant"}
                </Link>
              </li>
              <li>
                <a href="#" className="text-white/70 hover:text-white transition-colors">
                  {isArabic ? "سياسة الخصوصية" : "Privacy Policy"}
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-6">
              {isArabic ? "خدماتنا" : "Our Services"}
            </h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-white/70 hover:text-white transition-colors">
                  {isArabic ? "تغيير الزيت" : "Oil Change"}
                </a>
              </li>
              <li>
                <a href="#" className="text-white/70 hover:text-white transition-colors">
                  {isArabic ? "خدمة الفرامل" : "Brake Service"}
                </a>
              </li>
              <li>
                <a href="#" className="text-white/70 hover:text-white transition-colors">
                  {isArabic ? "إصلاح المحرك" : "Engine Repair"}
                </a>
              </li>
              <li>
                <a href="#" className="text-white/70 hover:text-white transition-colors">
                  {isArabic ? "خدمة الإطارات" : "Tire Service"}
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-6">
          <div className="mb-8">
            <h3 className="font-bold text-lg mb-6">
              {isArabic ? "تواصل معنا" : "Contact Us"}
            </h3>
            <address className="not-italic text-white/70 space-y-3">
              <p>{isArabic ? "الرياض، المملكة العربية السعودية" : "Riyadh, Saudi Arabia"}</p>
              <p>BB77LL@HOTMAIL.COM</p>
              <p>+966 123 456 789</p>
            </address>
          </div>
          
          <div className="border-t border-white/10 pt-6 text-center text-white/50">
            <p>
              {isArabic 
                ? "© 2025 صيانة سمارت. جميع الحقوق محفوظة."
                : "© 2025 Maintenance Smart. All rights reserved."
              }
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;