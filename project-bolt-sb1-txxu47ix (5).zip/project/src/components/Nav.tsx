import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "../lib/utils";
import { Menu, X, Car, Bot, LogIn, UserPlus } from "lucide-react";
import LanguageToggle from "./LanguageToggle";
import { useLanguage } from "../contexts/LanguageContext";
import { useAuth } from "../contexts/AuthContext";

const Nav = () => {
  const { isArabic, dir, fontFamily } = useLanguage();
  const { user, isAuthenticated, logout } = useAuth();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { name: isArabic ? "الرئيسية" : "Home", path: "/" },
    { name: isArabic ? "إضافة مركبة" : "Add Vehicle", path: "/add-vehicle" },
    { name: isArabic ? "مقارنة الورش" : "Compare Workshops", path: "/compare-workshops" },
    { name: isArabic ? "المساعد الذكي" : "AI Assistant", path: "/ai-assistant", icon: <Bot className="h-4 w-4 mr-1" /> },
  ];

  const authLinks = isAuthenticated ? [
    { name: isArabic ? "إدارة الورشة" : "Workshop Management", path: "/workshop-owner" },
    { 
      name: isArabic ? "تسجيل الخروج" : "Logout", 
      path: "#",
      onClick: () => {
        logout();
        window.location.href = '/';
      }
    }
  ] : [
    { 
      name: isArabic ? "تسجيل الدخول" : "Login", 
      path: "/login",
      icon: <LogIn className="h-4 w-4" />
    },
    { 
      name: isArabic ? "إنشاء حساب" : "Register", 
      path: "/register",
      icon: <UserPlus className="h-4 w-4" />
    }
  ];

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-3 px-4 sm:px-6 md:px-8",
        isScrolled
          ? "glass-card shadow-md"
          : "bg-transparent"
      )}
      dir={dir}
      style={{ fontFamily }}
    >
      <div className="container mx-auto">
        <div className="flex items-center justify-between">
          <Link 
            to="/" 
            className="flex items-center space-x-2 text-primary"
            aria-label={isArabic ? "صيانة سمارت - الرئيسية" : "Maintenance Smart - Home"}
          >
            <Car className="h-6 w-6" />
            <span className="font-semibold text-lg tracking-tight hidden sm:inline">
              {isArabic ? "صيانة سمارت" : "Maintenance Smart"}
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-6 xl:space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "relative font-medium text-sm transition-colors hover:text-primary flex items-center",
                  location.pathname === link.path
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
              >
                {link.icon && link.icon}
                {link.name}
                {location.pathname === link.path && (
                  <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-primary rounded-full animate-fade-in" />
                )}
              </Link>
            ))}
            
            {/* Auth Links */}
            {authLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={link.onClick}
                className={cn(
                  "relative font-medium text-sm transition-colors hover:text-primary flex items-center gap-2",
                  location.pathname === link.path
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
              >
                {link.icon && link.icon}
                {link.name}
              </Link>
            ))}
            
            <div className="flex items-center space-x-4">
              <LanguageToggle />
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center space-x-4">
            <LanguageToggle />
            <button
              className="text-primary hover:text-primary/80 transition-colors"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden absolute top-full left-0 right-0 glass-card-dark animate-fade-in py-4 px-4 sm:px-6">
            <div className="flex flex-col space-y-3">
              {[...navLinks, ...authLinks].map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={link.onClick}
                  className={cn(
                    "py-2.5 px-4 rounded-md transition-colors text-center font-medium flex items-center justify-center gap-2",
                    location.pathname === link.path
                      ? "bg-primary/20 text-white"
                      : "text-white/80 hover:bg-primary/10 hover:text-white"
                  )}
                >
                  {link.icon && link.icon}
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Nav;