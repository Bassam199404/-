import React, { useRef } from 'react';
import { Send, Image } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { cn } from '../lib/utils';

interface ChatInputProps {
  value: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  onImageUpload: () => void;
  placeholder?: string;
  disabled?: boolean;
  hasImage?: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({
  value,
  onChange,
  onSubmit,
  onImageUpload,
  placeholder,
  disabled = false,
  hasImage = false
}) => {
  const { isArabic } = useLanguage();
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!disabled && (value.trim() || hasImage)) {
      onSubmit();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex items-center gap-2">
      <input
        ref={inputRef}
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        disabled={disabled}
        className={cn(
          "flex-grow px-4 py-3 rounded-full border border-gray-300",
          "focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent",
          "text-sm bg-white transition-all",
          "placeholder:text-gray-400",
          disabled && "bg-gray-100 cursor-not-allowed"
        )}
      />
      
      <button
        type="button"
        onClick={onImageUpload}
        className={cn(
          "p-3 rounded-full transition-colors",
          disabled 
            ? "bg-gray-100 text-gray-400 cursor-not-allowed"
            : "bg-gray-200 text-gray-600 hover:bg-gray-300"
        )}
        disabled={disabled}
        title={isArabic ? "إرفاق صورة" : "Attach image"}
      >
        <Image className="h-5 w-5" />
      </button>

      <button
        type="submit"
        disabled={disabled || (!value.trim() && !hasImage)}
        className={cn(
          "p-3 rounded-full transition-colors",
          disabled || (!value.trim() && !hasImage)
            ? "bg-gray-200 text-gray-500 cursor-not-allowed"
            : "bg-primary text-white hover:bg-primary/90"
        )}
      >
        <Send className="h-5 w-5" />
      </button>
    </form>
  );
};

export default ChatInput;