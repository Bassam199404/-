import { GoogleGenerativeAI } from "@google/generative-ai";

// Initialize the Google Generative AI with your API key
const API_KEY = "sk-a3c856bb60014823976e164532229bb3";
const genAI = new GoogleGenerativeAI(API_KEY);

// Get the model - using gemini-pro-vision for image analysis
const textModel = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
const visionModel = genAI.getGenerativeModel({ model: "gemini-pro-vision" });

/**
 * Helper function to convert image URL to base64
 */
async function imageUrlToGenerativePart(imageUrl: string) {
  try {
    // Fetch the image
    const response = await fetch(imageUrl);
    if (!response.ok) throw new Error('Failed to fetch image');
    
    // Get the blob
    const blob = await response.blob();
    
    // Convert to base64
    const base64String = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          // Remove the data URL prefix
          const base64 = reader.result.split(',')[1];
          resolve(base64);
        } else {
          reject(new Error('Failed to convert image to base64'));
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });

    return {
      inlineData: {
        data: base64String,
        mimeType: blob.type
      }
    };
  } catch (error) {
    console.error('Error converting image:', error);
    throw error;
  }
}

/**
 * Generate content using Google's Gemini AI
 */
export const generateContent = async (prompt: string, isArabic: boolean = false): Promise<string> => {
  try {
    const enhancedPrompt = isArabic ? `
      أنت خبير في صيانة السيارات وإصلاحها. يرجى تقديم إجابة مفصلة ومفيدة باللغة العربية الفصحى السهلة.
      
      السؤال: ${prompt}
      
      ملاحظات للإجابة:
      - استخدم لغة واضحة وسهلة الفهم
      - قدم خطوات عملية عند الحاجة
      - اذكر التكلفة التقديرية إذا كان ذلك مناسباً
      - قدم نصائح إضافية مفيدة
    ` : prompt;

    const result = await textModel.generateContent(enhancedPrompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Error generating content with Gemini:", error);
    return isArabic 
      ? "عذراً، حدث خطأ في النظام. يرجى المحاولة مرة أخرى."
      : "Sorry, an error occurred. Please try again.";
  }
};

/**
 * Generate car maintenance advice with Arabic support
 */
export const getCarMaintenanceAdvice = async (question: string, isArabic: boolean = false): Promise<string> => {
  const prompt = isArabic ? `
    أنت خبير فني سيارات متخصص لديك خبرة واسعة في صيانة وإصلاح السيارات.
    يرجى تقديم نصيحة مفصلة ومفيدة للسؤال التالي المتعلق بالسيارات.
    قدم خطوات عملية عندما يكون ذلك مناسباً.

    السؤال: ${question}

    يرجى تنظيم إجابتك بالشكل التالي:
    1. التشخيص المبدئي
    2. الأسباب المحتملة
    3. الحلول الموصى بها
    4. التكلفة التقديرية (بالريال السعودي)
    5. نصائح إضافية للصيانة
  ` : `
    You are an expert automotive technician with extensive knowledge about car maintenance, 
    repairs, and diagnostics. Please provide helpful, accurate, and detailed advice for the 
    following car-related question. Include practical steps when applicable.
    
    Question: ${question}
  `;
  
  try {
    return await generateContent(prompt, isArabic);
  } catch (error) {
    console.error("Error getting car maintenance advice:", error);
    return isArabic
      ? "عذراً، لم أتمكن من الوصول إلى قاعدة المعرفة في الوقت الحالي. يرجى المحاولة مرة أخرى أو طرح سؤال آخر حول صيانة السيارات."
      : "I'm sorry, I couldn't connect to my knowledge base at the moment. Please try again later or ask another question about car maintenance.";
  }
};

/**
 * Analyze car problems from an image with Arabic support
 */
export const analyzeCarProblemFromImage = async (
  description: string, 
  imageUrl: string,
  isArabic: boolean = false
): Promise<string> => {
  try {
    const prompt = isArabic ? `
      أنت خبير في تشخيص أعطال السيارات ولوحة القيادة. قم بتحليل هذه الصورة وقدم:

      1. تحديد وشرح جميع الرموز المضيئة في لوحة القيادة
      2. مستوى خطورة كل رمز (منخفض، متوسط، عالي)
      3. الأسباب المحتملة لظهور كل رمز
      4. الإجراءات الموصى بها لكل مشكلة
      5. تقدير التكلفة المحتملة للإصلاح (بالريال السعودي)
      6. نصائح هامة للسلامة

      ملاحظات إضافية:
      - قدم شرحاً واضحاً لكل رمز باللغة العربية السهلة
      - حدد ما إذا كان آمناً الاستمرار في قيادة السيارة
      - اذكر إذا كانت المشكلة تتطلب زيارة فورية للورشة

      وصف المشكلة: ${description}
    ` : `
      You are an expert automotive diagnostician specializing in dashboard warning lights. Analyze this image and provide:

      1. Identification and explanation of all illuminated dashboard symbols
      2. Severity level of each symbol (low, medium, high)
      3. Potential causes for each warning light
      4. Recommended actions for each issue
      5. Estimated repair costs
      6. Important safety notes

      Additional notes:
      - Provide clear explanations for each symbol
      - Indicate if it's safe to continue driving
      - Mention if immediate workshop visit is required

      Problem description: ${description}
    `;

    // Convert image to Gemini-compatible format
    const imagePart = await imageUrlToGenerativePart(imageUrl);

    // Generate content with the vision model
    const result = await visionModel.generateContent([prompt, imagePart]);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Error analyzing car problem from image:", error);
    return isArabic
      ? "عذراً، لم أتمكن من تحليل الصورة في الوقت الحالي. يرجى التأكد من أن الصورة واضحة وتظهر لوحة القيادة بشكل جيد، ثم حاول مرة أخرى."
      : "I'm sorry, I couldn't analyze the image at the moment. Please ensure the image is clear and shows the dashboard properly, then try again.";
  }
};