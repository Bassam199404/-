import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import { z } from 'zod';
import { addWorkshop, updateWorkshop, getWorkshopsByIds } from './workshopService';

// Workshop owner schema
export const workshopOwnerSchema = z.object({
  id: z.string().uuid(),
  user_id: z.string(),
  workshop_id: z.string().uuid().optional(),
  business_name: z.string().min(3),
  business_license: z.string().min(3),
  contact_name: z.string().min(3),
  contact_phone: z.string().min(8),
  contact_email: z.string().email(),
  verified: z.boolean().default(false),
  created_at: z.string().datetime(),
});

export type WorkshopOwner = z.infer<typeof workshopOwnerSchema>;

// Workshop data schema
export const workshopDataSchema = z.object({
  name: z.string().min(3),
  location: z.string().min(3),
  phone: z.string().min(8),
  hours: z.string().min(3),
  services: z.array(z.string()),
  specialties: z.array(z.string()),
  images: z.array(z.string()),
  description: z.string().min(10),
});

export type WorkshopData = z.infer<typeof workshopDataSchema>;

// Register as workshop owner
export const registerWorkshopOwner = async (ownerData: Omit<WorkshopOwner, 'id' | 'user_id' | 'created_at' | 'verified'>) => {
  try {
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) throw new Error('User must be logged in');

    const { data, error } = await supabase
      .from('workshop_owners')
      .insert({
        ...ownerData,
        user_id: user.id,
        verified: false
      })
      .select()
      .single();

    if (error) throw error;
    return { success: true, data };
  } catch (error) {
    console.error('Error registering workshop owner:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'An unexpected error occurred' 
    };
  }
};

// Add workshop data
export const addWorkshopData = async (workshopData: WorkshopData) => {
  try {
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) throw new Error('User must be logged in');

    // First, add the workshop
    const { data: workshop, error: workshopError } = await supabase
      .from('workshops')
      .insert({
        ...workshopData,
        rating: 0,
        review_count: 0,
        image: workshopData.images[0] || '',
        created_at: new Date().toISOString()
      })
      .select()
      .single();

    if (workshopError) throw workshopError;

    // Update workshop owner with workshop_id
    const { error: updateError } = await supabase
      .from('workshop_owners')
      .update({ workshop_id: workshop.id })
      .eq('user_id', user.id);

    if (updateError) throw updateError;

    return { success: true, data: workshop };
  } catch (error) {
    console.error('Error adding workshop data:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'An unexpected error occurred' 
    };
  }
};

// Update workshop data
export const updateWorkshopData = async (workshopId: string, workshopData: Partial<WorkshopData>) => {
  try {
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) throw new Error('User must be logged in');

    const { data, error } = await supabase
      .from('workshops')
      .update(workshopData)
      .eq('id', workshopId)
      .select()
      .single();

    if (error) throw error;
    return { success: true, data };
  } catch (error) {
    console.error('Error updating workshop data:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'An unexpected error occurred' 
    };
  }
};

// Get workshop owner data
export const getWorkshopOwnerData = async () => {
  try {
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) throw new Error('User must be logged in');

    const { data: ownerData, error: ownerError } = await supabase
      .from('workshop_owners')
      .select('*, workshops(*)')
      .eq('user_id', user.id)
      .single();

    if (ownerError) throw ownerError;
    return { success: true, data: ownerData };
  } catch (error) {
    console.error('Error getting workshop owner data:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'An unexpected error occurred' 
    };
  }
};

// Upload workshop images
export const uploadWorkshopImages = async (files: File[]) => {
  try {
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) throw new Error('User must be logged in');

    const urls = await Promise.all(
      files.map(async (file) => {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = `workshops/${user.id}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('workshop-images')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('workshop-images')
          .getPublicUrl(filePath);

        return publicUrl;
      })
    );

    return { success: true, urls };
  } catch (error) {
    console.error('Error uploading workshop images:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'An unexpected error occurred' 
    };
  }
};

// Delete workshop image
export const deleteWorkshopImage = async (imageUrl: string) => {
  try {
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) throw new Error('User must be logged in');

    const path = imageUrl.split('/').pop();
    if (!path) throw new Error('Invalid image URL');

    const { error } = await supabase.storage
      .from('workshop-images')
      .remove([`workshops/${user.id}/${path}`]);

    if (error) throw error;
    return { success: true };
  } catch (error) {
    console.error('Error deleting workshop image:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'An unexpected error occurred' 
    };
  }
};