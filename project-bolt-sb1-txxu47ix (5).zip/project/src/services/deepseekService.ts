import axios from 'axios';

const DEEPSEEK_API_URL = 'https://api.deepseek.com/v1/chat/completions';
const API_KEY = 'sk-a3c856bb60014823976e164532229bb3';

/**
 * Generate a response using DeepSeek's API
 */
export const generateDeepSeekResponse = async (prompt: string, isArabic: boolean = false): Promise<string> => {
  try {
    const systemPrompt = isArabic
      ? "أنت مساعد خبير في صيانة السيارات وإصلاحها. قدم إجابات دقيقة ومفيدة باللغة العربية."
      : "You are an expert automotive maintenance and repair assistant. Provide accurate and helpful responses.";

    const response = await axios.post(
      DEEPSEEK_API_URL,
      {
        model: "deepseek-chat",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: prompt }
        ]
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return response.data.choices[0].message.content;
  } catch (error) {
    console.error("Error generating DeepSeek response:", error);
    return isArabic
      ? "عذراً، حدث خطأ في النظام. يرجى المحاولة مرة أخرى."
      : "Sorry, an error occurred. Please try again.";
  }
};

/**
 * Analyze car problems and provide maintenance advice
 */
export const analyzeCarProblem = async (
  description: string,
  isArabic: boolean = false
): Promise<string> => {
  const prompt = isArabic
    ? `تحليل مشكلة السيارة التالية وتقديم نصائح مفصلة:

       المشكلة: ${description}

       يرجى تقديم:
       1. التشخيص المحتمل
       2. الحلول الموصى بها
       3. تقدير التكلفة
       4. نصائح للصيانة الوقائية
       5. متى يجب استشارة ميكانيكي`
    : `Analyze the following car problem and provide detailed advice:

       Problem: ${description}

       Please provide:
       1. Potential diagnosis
       2. Recommended solutions
       3. Cost estimate
       4. Preventive maintenance tips
       5. When to consult a mechanic`;

  return generateDeepSeekResponse(prompt, isArabic);
};

/**
 * Analyze car problems from image description
 */
export const analyzeCarProblemFromImage = async (
  description: string,
  imageUrl: string,
  isArabic: boolean = false
): Promise<string> => {
  // For now, we'll just analyze the description since we can't directly process images
  const prompt = isArabic
    ? `تحليل مشكلة السيارة من الوصف والصورة:

       الوصف: ${description}

       يرجى تقديم:
       1. التشخيص المحتمل
       2. مستوى الخطورة
       3. الإجراءات الموصى بها
       4. تقدير التكلفة
       5. نصائح للسلامة`
    : `Analyze the car problem from the description and image:

       Description: ${description}

       Please provide:
       1. Potential diagnosis
       2. Severity level
       3. Recommended actions
       4. Cost estimate
       5. Safety tips`;

  return generateDeepSeekResponse(prompt, isArabic);
};