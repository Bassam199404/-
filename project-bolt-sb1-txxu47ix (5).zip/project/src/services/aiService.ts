import { apiKeys } from '../config/apiKeys';
import { getWorkshops } from './workshopService';
import { calculateDistance } from './mapsService';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  location?: {
    lat: number;
    lng: number;
    address?: string;
  };
}

// Enhanced AI response function with Arabic support
export const getAiResponse = async (
  userInput: string, 
  conversationHistory: Message[],
  userLocation?: { lat: number, lng: number } | null
): Promise<string> => {
  try {
    // For demo purposes, we'll use a mock response system
    // In a real application, this would call an actual AI API like OpenAI
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Get a response based on the user input
    return getMockResponse(userInput, conversationHistory, userLocation);
  } catch (error) {
    console.error('Error getting AI response:', error);
    throw new Error('Failed to get AI response');
  }
};

// Enhanced mock response function with more sophisticated responses
const getMockResponse = (
  userInput: string, 
  conversationHistory: Message[],
  userLocation?: { lat: number, lng: number } | null
): string => {
  const input = userInput.toLowerCase();
  
  // Vehicle Diagnostics
  if (input.includes('check engine') || input.includes('فحص المحرك')) {
    return 'Based on your description, here are the possible issues:\n\n' +
           '1. Oxygen sensor malfunction (40% probability)\n' +
           '2. Loose gas cap (30% probability)\n' +
           '3. Catalytic converter issues (20% probability)\n' +
           '4. Spark plug problems (10% probability)\n\n' +
           'Recommended action: Visit a workshop for diagnostic scanning. I can help you find the nearest certified workshop.';
  }
  
  // Maintenance Schedule
  if (input.includes('maintenance schedule') || input.includes('جدول الصيانة')) {
    return 'Here\'s your personalized maintenance schedule:\n\n' +
           '1. Every 5,000 km:\n' +
           '   - Oil change\n' +
           '   - Filter check\n' +
           '   - Tire pressure check\n\n' +
           '2. Every 10,000 km:\n' +
           '   - Brake inspection\n' +
           '   - Battery test\n' +
           '   - Air filter replacement\n\n' +
           '3. Every 20,000 km:\n' +
           '   - Major service\n' +
           '   - Transmission fluid check\n' +
           '   - Suspension inspection';
  }
  
  // Cost Estimation
  if (input.includes('cost') || input.includes('price') || input.includes('تكلفة') || input.includes('سعر')) {
    return 'Based on current market rates and your location in Riyadh:\n\n' +
           '1. Basic Service:\n' +
           '   - Oil change: 150-300 SAR\n' +
           '   - Filter replacement: 100-200 SAR\n' +
           '   - Basic inspection: 100-150 SAR\n\n' +
           '2. Major Service:\n' +
           '   - Full service: 500-1000 SAR\n' +
           '   - Brake service: 300-600 SAR\n' +
           '   - AC service: 200-400 SAR\n\n' +
           'Would you like me to find workshops offering these services?';
  }
  
  // Workshop Recommendations
  if (input.includes('workshop') || input.includes('ورشة')) {
    return 'Based on your vehicle type and location, I recommend:\n\n' +
           '1. Al-Faisal Auto Center (4.8★)\n' +
           '   - Certified technicians\n' +
           '   - Advanced diagnostic equipment\n' +
           '   - Competitive pricing\n\n' +
           '2. Prestige Car Care (4.9★)\n' +
           '   - Premium service\n' +
           '   - Specialized in luxury vehicles\n' +
           '   - Latest technology\n\n' +
           'Would you like to schedule an appointment at either workshop?';
  }
  
  // Part Recommendations
  if (input.includes('parts') || input.includes('قطع غيار')) {
    return 'Here are my recommendations for genuine parts:\n\n' +
           '1. Original Parts:\n' +
           '   - Dealer price: 1000-1200 SAR\n' +
           '   - Warranty: 1 year\n\n' +
           '2. OEM Parts:\n' +
           '   - Market price: 700-900 SAR\n' +
           '   - Warranty: 6 months\n\n' +
           '3. Aftermarket Parts:\n' +
           '   - Price: 400-600 SAR\n' +
           '   - Warranty: 3 months\n\n' +
           'Would you like me to locate these parts from trusted suppliers?';
  }
  
  // Emergency Assistance
  if (input.includes('emergency') || input.includes('breakdown') || input.includes('طوارئ')) {
    return 'Emergency assistance protocol activated:\n\n' +
           '1. Current location identified\n' +
           '2. Nearest emergency services:\n' +
           '   - Roadside assistance: 5 min away\n' +
           '   - Tow truck: 15 min away\n' +
           '   - Emergency workshop: 10 min away\n\n' +
           'Would you like me to contact any of these services for you?';
  }
  
  // Default response with workshop suggestions
  return 'I can help you with:\n\n' +
         '1. Vehicle diagnostics and troubleshooting\n' +
         '2. Maintenance schedules and reminders\n' +
         '3. Cost estimates for repairs and services\n' +
         '4. Workshop recommendations and appointments\n' +
         '5. Parts recommendations and sourcing\n' +
         '6. Emergency roadside assistance\n\n' +
         'What specific assistance do you need?';
};

// AI-powered vehicle problem analysis
export const analyzeVehicleProblem = async (description: string, images?: string[]): Promise<{
  diagnosis: string;
  severity: 'low' | 'medium' | 'high';
  recommendations: string[];
  estimatedCost: { min: number; max: number };
  nearbyWorkshops: string[];
}> => {
  // Simulate AI analysis
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  return {
    diagnosis: "Based on the description and images, the likely issue is a faulty oxygen sensor affecting fuel mixture.",
    severity: "medium",
    recommendations: [
      "Schedule diagnostic scan",
      "Check engine light inspection",
      "Oxygen sensor replacement if confirmed"
    ],
    estimatedCost: { min: 300, max: 600 },
    nearbyWorkshops: [
      "Al-Faisal Auto Center",
      "Quick Fix Auto Center",
      "Riyadh Motors Workshop"
    ]
  };
};

// AI-powered maintenance schedule generator
export const generateMaintenanceSchedule = async (
  make: string,
  model: string,
  year: number,
  mileage: number
): Promise<{
  nextService: string;
  dueDate: string;
  recommendations: string[];
  estimatedCosts: { service: string; cost: number }[];
}> => {
  // Simulate AI analysis
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  return {
    nextService: "Major Service Due",
    dueDate: "In 2 weeks or 1,000 km",
    recommendations: [
      "Oil and filter change",
      "Brake system inspection",
      "Air filter replacement",
      "Battery health check"
    ],
    estimatedCosts: [
      { service: "Oil Change", cost: 200 },
      { service: "Filters", cost: 150 },
      { service: "Brake Inspection", cost: 100 },
      { service: "Battery Check", cost: 50 }
    ]
  };
};

// AI-powered cost estimator
export const estimateRepairCost = async (
  problem: string,
  make: string,
  model: string,
  year: number
): Promise<{
  estimatedRange: { min: number; max: number };
  breakdown: { item: string; cost: number }[];
  confidence: number;
  recommendations: string[];
}> => {
  // Simulate AI analysis
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  return {
    estimatedRange: { min: 800, max: 1200 },
    breakdown: [
      { item: "Parts", cost: 500 },
      { item: "Labor", cost: 300 },
      { item: "Diagnostics", cost: 100 }
    ],
    confidence: 0.85,
    recommendations: [
      "Get multiple quotes",
      "Request OEM parts",
      "Check warranty coverage"
    ]
  };
};

// AI-powered workshop matcher
export const findBestWorkshops = async (
  problem: string,
  make: string,
  location: { lat: number; lng: number }
): Promise<{
  matches: {
    workshop: string;
    matchScore: number;
    specialties: string[];
    distance: string;
    estimatedCost: number;
  }[];
}> => {
  // Simulate AI analysis
  await new Promise(resolve => setTimeout(resolve, 1200));
  
  return {
    matches: [
      {
        workshop: "Al-Faisal Auto Center",
        matchScore: 0.95,
        specialties: ["Toyota", "Lexus", "Honda"],
        distance: "3.2 km",
        estimatedCost: 850
      },
      {
        workshop: "Prestige Car Care",
        matchScore: 0.88,
        specialties: ["Luxury Vehicles", "German Cars"],
        distance: "5.7 km",
        estimatedCost: 950
      }
    ]
  };
};

// AI-powered part recommendations
export const recommendParts = async (
  part: string,
  make: string,
  model: string,
  year: number
): Promise<{
  recommendations: {
    type: 'OEM' | 'Aftermarket' | 'Used';
    brand: string;
    price: number;
    quality: number;
    warranty: string;
    availability: 'In Stock' | 'Order Required';
  }[];
}> => {
  // Simulate AI analysis
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  return {
    recommendations: [
      {
        type: 'OEM',
        brand: 'Toyota Genuine',
        price: 1200,
        quality: 0.98,
        warranty: '1 year',
        availability: 'In Stock'
      },
      {
        type: 'Aftermarket',
        brand: 'Bosch',
        price: 800,
        quality: 0.92,
        warranty: '6 months',
        availability: 'In Stock'
      }
    ]
  };
};