import { fallbackWorkshops } from '../lib/supabase';
import { findBestWorkshops, recommendParts } from './aiService';

export interface Workshop {
  id: string;
  name: string;
  rating: number;
  review_count: number;
  image: string;
  location: string;
  distance: string;
  hours: string;
  phone: string;
  services: string[];
  specialties: string[];
  aiFeatures?: string[];
  aiScore?: number;
  aiRecommendation?: string;
  description?: string;
  images?: string[]; // Add images array
}

// Store workshops in memory for demo
let workshops = [...fallbackWorkshops];

export const getWorkshops = async (): Promise<Workshop[]> => {
  try {
    // Add AI-powered features to workshops
    const enhancedWorkshops = workshops.map(workshop => ({
      ...workshop,
      images: [workshop.image], // Initialize images array with main image
      aiScore: Math.random() * 0.3 + 0.7, // 0.7 to 1.0
      aiRecommendation: Math.random() > 0.5 ? "Highly Recommended" : "Recommended",
      aiFeatures: [
        "Smart Diagnostics",
        "Predictive Maintenance",
        "Real-time Updates",
        "Digital Inspection"
      ]
    }));
    
    return enhancedWorkshops;
  } catch (error) {
    console.log('Error in getWorkshops:', error);
    return fallbackWorkshops;
  }
};

export const addWorkshop = async (workshop: Omit<Workshop, 'id' | 'rating' | 'review_count'>): Promise<Workshop> => {
  const newWorkshop: Workshop = {
    ...workshop,
    id: crypto.randomUUID(),
    rating: 0,
    review_count: 0,
    image: workshop.images?.[0] || 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=1000&auto=format&fit=crop'
  };
  
  workshops.push(newWorkshop);
  return newWorkshop;
};

export const updateWorkshop = async (id: string, data: Partial<Workshop>): Promise<Workshop | null> => {
  const index = workshops.findIndex(w => w.id === id);
  if (index === -1) return null;
  
  // If new images are provided, update the main image
  if (data.images?.length) {
    data.image = data.images[0];
  }
  
  workshops[index] = {
    ...workshops[index],
    ...data
  };
  
  return workshops[index];
};

export const searchWorkshops = async (searchTerm: string): Promise<Workshop[]> => {
  try {
    // If search term is empty, return all workshops
    if (!searchTerm.trim()) {
      return await getWorkshops();
    }
    
    // Use AI to enhance search results
    const filteredWorkshops = workshops.filter(workshop => 
      workshop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      workshop.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      workshop.specialties.some(s => s.toLowerCase().includes(searchTerm.toLowerCase())) ||
      workshop.services.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    
    // Add AI-powered recommendations
    return filteredWorkshops.map(workshop => ({
      ...workshop,
      images: [workshop.image], // Initialize images array with main image
      aiScore: Math.random() * 0.3 + 0.7,
      aiRecommendation: Math.random() > 0.5 ? "Highly Recommended" : "Recommended",
      aiFeatures: [
        "Smart Search Match",
        "Service Compatibility",
        "Quality Prediction",
        "Price Analysis"
      ]
    }));
  } catch (error) {
    console.log('Error in searchWorkshops:', error);
    return fallbackWorkshops;
  }
};

export const getWorkshopsByIds = async (ids: string[]): Promise<Workshop[]> => {
  try {
    if (ids.length === 0) return [];
    
    // Get workshops and enhance with AI features
    const filteredWorkshops = workshops
      .filter(workshop => ids.includes(workshop.id))
      .map(workshop => ({
        ...workshop,
        images: [workshop.image], // Initialize images array with main image
        aiScore: Math.random() * 0.3 + 0.7,
        aiRecommendation: "AI Matched Workshop",
        aiFeatures: [
          "Personalized Match",
          "Service Optimization",
          "Quality Assurance",
          "Smart Scheduling"
        ]
      }));
    
    return filteredWorkshops;
  } catch (error) {
    console.log('Error in getWorkshopsByIds:', error);
    return fallbackWorkshops.filter(workshop => ids.includes(workshop.id));
  }
};

// New AI-powered functions

export const getWorkshopRecommendations = async (
  vehicleType: string,
  serviceNeeded: string,
  location: { lat: number; lng: number }
) => {
  try {
    const recommendations = await findBestWorkshops(serviceNeeded, vehicleType, location);
    return recommendations.matches;
  } catch (error) {
    console.log('Error getting workshop recommendations:', error);
    return [];
  }
};

export const getPartRecommendations = async (
  partType: string,
  vehicleMake: string,
  vehicleModel: string,
  vehicleYear: number
) => {
  try {
    const recommendations = await recommendParts(
      partType,
      vehicleMake,
      vehicleModel,
      vehicleYear
    );
    return recommendations;
  } catch (error) {
    console.log('Error getting part recommendations:', error);
    return null;
  }
};