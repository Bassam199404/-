import { googleMapsConfig, loadGoogleMapsScript } from '../config/apiKeys';

// Interface for location data
export interface Location {
  lat: number;
  lng: number;
  address?: string;
}

// Get user's current location
export const getCurrentLocation = (): Promise<Location> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      // Fallback to default location (Riyadh)
      resolve(googleMapsConfig.defaultCenter);
      return;
    }
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
      },
      (error) => {
        console.error('Error getting location:', error);
        // Fallback to default location (Riyadh)
        resolve(googleMapsConfig.defaultCenter);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  });
};

// Calculate distance between two points
export const calculateDistance = (origin: Location, destination: Location): Promise<number> => {
  return new Promise((resolve) => {
    try {
      // For demo purposes, we'll use a direct distance calculation
      const directDistance = calculateDirectDistance(origin, destination);
      resolve(directDistance);
    } catch (error) {
      console.error('Error calculating distance:', error);
      // Return a random distance between 1 and 15 km
      resolve(Math.random() * 14 + 1);
    }
  });
};

// Calculate direct distance (as the crow flies) using Haversine formula
const calculateDirectDistance = (origin: Location, destination: Location): number => {
  const R = 6371; // Earth's radius in km
  const dLat = toRad(destination.lat - origin.lat);
  const dLng = toRad(destination.lng - origin.lng);
  
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(origin.lat)) * Math.cos(toRad(destination.lat)) * 
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  
  return distance;
};

// Convert degrees to radians
const toRad = (value: number): number => {
  return value * Math.PI / 180;
};

// Geocode an address to get coordinates
export const geocodeAddress = (address: string): Promise<Location> => {
  return new Promise((resolve, reject) => {
    // For demo purposes, return a random location near Riyadh
    const randomLat = 24.7136 + (Math.random() * 0.1 - 0.05);
    const randomLng = 46.6753 + (Math.random() * 0.1 - 0.05);
    
    resolve({
      lat: randomLat,
      lng: randomLng,
      address: address || "Riyadh, Saudi Arabia"
    });
  });
};

// Get nearby workshops
export const getNearbyWorkshops = (location: Location, radius: number = 5000): Promise<any[]> => {
  return new Promise((resolve) => {
    // For demo purposes, return an empty array
    resolve([]);
  });
};