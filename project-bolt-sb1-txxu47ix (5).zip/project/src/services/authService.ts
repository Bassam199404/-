import { supabase, testConnection } from '../lib/supabase';
import { AuthError } from '@supabase/supabase-js';

// Helper function to handle Supabase errors
const handleSupabaseError = (error: unknown): string => {
  if (error instanceof AuthError) {
    switch (error.status) {
      case 400:
        if (error.message.includes('invalid_credentials')) {
          return 'Invalid email or password';
        }
        if (error.message.includes('email_confirmation') || error.message.includes('email_not_confirmed')) {
          return 'Please check your email for confirmation link';
        }
        return 'Invalid request. Please check your input';
      case 422:
        return 'Email already registered';
      case 429:
        return 'Too many requests. Please try again later';
      default:
        return error.message;
    }
  }
  if (error instanceof Error) {
    return error.message;
  }
  return 'An unexpected error occurred';
};

// Login function
export const loginUser = async (email: string, password: string) => {
  try {
    // Test connection first
    const connectionTest = await testConnection();
    if (!connectionTest.success) {
      return {
        success: false,
        message: connectionTest.error
      };
    }

    if (!email || !password) {
      return {
        success: false,
        message: 'Email and password are required'
      };
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) {
      console.error('Login error:', error);
      return { 
        success: false, 
        message: handleSupabaseError(error)
      };
    }

    if (!data.user) {
      return {
        success: false,
        message: 'No user data returned'
      };
    }

    // Get user profile data
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', data.user.id)
      .maybeSingle();

    if (profileError) {
      console.error('Profile fetch error:', profileError);
      // Return basic user data if profile fetch fails
      return {
        success: true,
        user: {
          id: data.user.id,
          name: data.user.user_metadata?.name || '',
          phone: data.user.user_metadata?.phone || '',
          role: 'user'
        }
      };
    }

    return { 
      success: true,
      user: {
        id: data.user.id,
        name: profile?.name || data.user.user_metadata?.name || '',
        phone: profile?.phone || data.user.user_metadata?.phone || '',
        role: 'user'
      }
    };
  } catch (error) {
    console.error('Login error:', error);
    return { 
      success: false, 
      message: handleSupabaseError(error)
    };
  }
};

// Register function
export const registerUser = async (
  name: string, 
  email: string, 
  phone: string, 
  password: string
) => {
  try {
    // Test connection first
    const connectionTest = await testConnection();
    if (!connectionTest.success) {
      throw new Error(connectionTest.error);
    }

    // Validate input
    if (!email || !password || !name) {
      return {
        success: false,
        message: 'Name, email, and password are required'
      };
    }

    // Password validation
    if (password.length < 6) {
      return {
        success: false,
        message: 'Password must be at least 6 characters long'
      };
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
          phone,
          role: 'user'
        }
      }
    });

    if (error) {
      console.error('Registration error:', error);
      return { 
        success: false, 
        message: handleSupabaseError(error)
      };
    }

    if (!data.user) {
      return {
        success: false,
        message: 'No user data returned'
      };
    }

    return { 
      success: true,
      message: 'Registration successful. Please check your email for confirmation.',
      user: {
        id: data.user.id,
        name,
        phone,
        role: 'user'
      }
    };
  } catch (error) {
    console.error('Registration error:', error);
    return { 
      success: false, 
      message: handleSupabaseError(error)
    };
  }
};

// Reset password
export const resetPassword = async (email: string) => {
  try {
    if (!email) {
      return {
        success: false,
        message: 'Email is required'
      };
    }

    const { error } = await supabase.auth.resetPasswordForEmail(email);
    
    if (error) {
      return {
        success: false,
        message: handleSupabaseError(error)
      };
    }

    return {
      success: true,
      message: 'Password reset email sent'
    };
  } catch (error) {
    console.error('Reset password error:', error);
    return {
      success: false,
      message: handleSupabaseError(error)
    };
  }
};

// Get current user
export const getCurrentUser = async () => {
  try {
    const { data: { user }, error } = await supabase.auth.getUser();
    
    if (error || !user) {
      console.error('Error getting user:', error);
      return null;
    }

    // Get user profile
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();

    if (profileError) {
      console.error('Error fetching profile:', profileError);
      // Return basic user info without profile
      return {
        id: user.id,
        name: user.user_metadata?.name || '',
        phone: user.user_metadata?.phone || '',
        role: 'user'
      };
    }

    return {
      id: user.id,
      name: profile?.name || user.user_metadata?.name || '',
      phone: profile?.phone || user.user_metadata?.phone || '',
      role: 'user'
    };
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
};