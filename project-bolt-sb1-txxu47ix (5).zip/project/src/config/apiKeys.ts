/**
 * API Keys Configuration
 * 
 * This file contains API keys and configuration for external services.
 * In a production environment, these should be stored in environment variables.
 */

export const apiKeys = {
  // Google Maps API Key
  googleMaps: 'AIzaSyA_7yZFoEPlGqJ_IOXP3CzgIPDeduPGt98',
  
  // OpenAI API Key (for AI Assistant)
  openAI: 'sk-demo-key-not-real',
  
  // Add other API keys as needed
};

// Google Maps configuration
export const googleMapsConfig = {
  apiKey: apiKeys.googleMaps,
  libraries: ['places', 'geometry'],
  defaultCenter: { lat: 24.7136, lng: 46.6753 }, // Riyadh coordinates
  defaultZoom: 12,
};

// Export a utility function to load the Google Maps script
export const loadGoogleMapsScript = (callback: () => void): void => {
  // Check if script is already loaded
  if (window.google && window.google.maps) {
    callback();
    return;
  }
  
  // Create script element
  const script = document.createElement('script');
  script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKeys.googleMaps}&libraries=places,geometry`;
  script.async = true;
  script.defer = true;
  
  // Set callback
  script.onload = callback;
  
  // Append to document
  document.head.appendChild(script);
};