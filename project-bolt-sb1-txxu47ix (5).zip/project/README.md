# Maintenance Smart

A bilingual (Arabic/English) car maintenance and workshop management platform built with React, Vite, and Supabase.

## Features

- 🚗 Vehicle maintenance tracking
- 🔧 Workshop comparison and booking
- 🤖 AI-powered maintenance assistant
- 🗺️ Workshop location mapping
- 🌐 Bilingual support (Arabic/English)
- 👤 User and workshop owner portals

## Tech Stack

- React
- TypeScript
- Vite
- Tailwind CSS
- Supabase
- React Router
- React Query

## Getting Started

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/maintenance-smart.git
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file with your Supabase credentials:
   ```
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.