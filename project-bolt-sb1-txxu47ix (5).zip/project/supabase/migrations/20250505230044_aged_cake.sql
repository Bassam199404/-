/*
  # Update profiles table for phone-based authentication
  
  1. Changes
    - Drop email-based policies with CASCADE
    - Remove email column
    - Make phone required and unique
    - Add new phone-based policies
  
  2. Security
    - Update RLS policies for phone authentication
*/

-- Drop existing policies with CASCADE to remove dependencies
DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON profiles CASCADE;
DROP POLICY IF EXISTS "Enable read access for all users" ON profiles CASCADE;
DROP POLICY IF EXISTS "Enable update for users based on email" ON profiles CASCADE;

-- Update profiles table structure
ALTER TABLE profiles DROP COLUMN IF EXISTS email CASCADE;
ALTER TABLE profiles ALTER COLUMN phone SET NOT NULL;
ALTER TABLE profiles ADD CONSTRAINT profiles_phone_key UNIQUE (phone);

-- Create new policies for phone-based authentication
CREATE POLICY "Enable insert access for authenticated users"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable read access for all users"
  ON profiles
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable update for users based on phone"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'phone' = phone)
  WITH CHECK (auth.jwt() ->> 'phone' = phone);