/*
  # Fix profiles table RLS policies

  1. Security Updates
    - Drop existing policies
    - Create new, more permissive policies for profile creation
    - Add public read access for all profiles
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can insert their own profile" ON profiles;
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Public can read workshop owner profiles" ON profiles;

-- Create new policies
CREATE POLICY "Enable insert access for authenticated users"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable read access for all users"
  ON profiles
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable update for users based on email"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'email' = email)
  WITH CHECK (auth.jwt() ->> 'email' = email);